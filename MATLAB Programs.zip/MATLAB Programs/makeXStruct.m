%pitchStructMaker.m
%does blah  fill this in and see below.
%Make a nice struct X from a pitch tier.
% X contains the pitch 'curvelets, start and end times, and vec of pitches

%% get variables if not already available:
if ~exist('pitchVals') %should also have pitchTimes()
    msg = 'Loading pitch data...'
    readPraatPitchTierOOB; %gets timeVals and dataVals and maxTime
    makeContinuousPitchSignal.m; %makes uniformly sampled
    %  pitch data out of pitchTimes and pitchVals
    %  These are the pitch curvelets.  They are separated, in voiced
    %  regions (times) only, but each curvelet chunk is continuous
    %  Also produces pitch graphs 100- 103
    msg = 'pitch data loaded'
end

if ~exist('intensityVals') %should also have pitchTimes()
    msg = 'Loading intensity data...'
    readPraatIntensityTierOOB; %gets timeVals and dataVals and maxTime
    makeContinuousIntensitySignal.m; %makes uniformly sampled
    %  pitch data out of pitchTimes and pitchVals
    %  These are the pitch curvelets.  They are separated, in voiced
    %  regions (times) only, but each curvelet chunk is continuous
    %  Also produces pitch graphs 100- 103
    msg = 'intensity data loaded'
end


%% stuff
numPitchTimes = length(pitchTimes);
dd = diff(pitchTimes);
minDelta = min(dd); %this is probably 0.0107 seconds
safeDelta = minDelta * 1.1; %to avoid possible precision problems
%if jump in time is greater this, it's a 'gap'

%% Loop thru pitchTimes and create 'chunks' for the struct X: 
clear X ;%the struct
chunkNum = 0;
pitchDataVec= []; %start building this for first chunk
intensityDataVec = [];
timeVec= [];
startTime = pitchTimes(1); %for starters
for iTime = 1:numPitchTimes-1
    thisTime = pitchTimes(iTime);
    thisPitchVal = pitchVals(iTime);
    thisIntensityVal = intensityVals(iTime);
    if (pitchTimes(iTime+1) - thisTime) < safeDelta
        %then need to add to the vecs, but don't go to new chunk
        timeVec = [timeVec,thisTime];
        pitchDataVec = [pitchDataVec, thisPitchVal];
        intensityDataVec = [intensityDataVec, thisIntensityVal];
        msg = 'debug';
        %continue
    else %gap large, save this chunk and get ready for next chunk:
        chunkNum =chunkNum+1;
        X(chunkNum).timeVec = timeVec;
        X(chunkNum).pitchDataVec = pitchDataVec;
        X(chunkNum).intensityDataVec = intensityDataVec;
        timeVec = []; %for next chunk
        pitchDataVec = [];
        intensityDatVec = [];
    end

end



%% Calculate some of the statistics that are used in the Levitan paper.

% Set the seed so that all randomly generated data is reproducible.
% So far, I've used 1 and 2 as seeds.
rng(1);

%% Create vectors of all pairs of the turn data.

% Initilize the vectors.  These are the normalized mean, max, and min 
% pitch and intensity, and the speaker rate of each speaker in a turn.
thisNormMeanPitchVec = [];
nextNormMeanPitchVec = [];
thisNormMaxPitchVec = [];
nextNormMaxPitchVec = [];
thisNormMinPitchVec = [];
nextNormMinPitchVec = [];
thisNormMeanIntensityVec = [];
nextNormMeanIntensityVec = [];
thisNormMaxIntensityVec = [];
nextNormMaxIntensityVec = [];
thisNormMinIntensityVec = [];
nextNormMinIntensityVec = [];


% Loop over all entires of Pr.
for Pindx = 1:length(Pr)
    
    % Get the first and second speaker's normalized mean, max, and min, 
    % pitch data for each turn and add it to the vector.
    thisNormMeanPitchVec = [thisNormMeanPitchVec; Pr(Pindx).thisNormPitchMean];
    nextNormMeanPitchVec = [nextNormMeanPitchVec; Pr(Pindx).nextNormPitchMean];
    thisNormMaxPitchVec = [thisNormMaxPitchVec; Pr(Pindx).thisNormPitchMax];
    nextNormMaxPitchVec = [nextNormMaxPitchVec; Pr(Pindx).nextNormPitchMax];
    thisNormMinPitchVec = [thisNormMinPitchVec; Pr(Pindx).thisNormPitchMin];
    nextNormMinPitchVec = [nextNormMinPitchVec; Pr(Pindx).nextNormPitchMin];
    
    % And do the same for the intensity data.
    thisNormMeanIntensityVec = [thisNormMeanIntensityVec; Pr(Pindx).thisNormIntensityMean];
    nextNormMeanIntensityVec = [nextNormMeanIntensityVec; Pr(Pindx).nextNormIntensityMean];
    thisNormMaxIntensityVec = [thisNormMaxIntensityVec; Pr(Pindx).thisNormIntensityMax];
    nextNormMaxIntensityVec = [nextNormMaxIntensityVec; Pr(Pindx).nextNormIntensityMax];
    thisNormMinIntensityVec = [thisNormMinIntensityVec; Pr(Pindx).thisNormIntensityMin];
    nextNormMinIntensityVec = [nextNormMinIntensityVec; Pr(Pindx).nextNormIntensityMin];

end

%% Create the PARTNER DIFFERENCE vectors, used in the Levitan analysis.

% Initialize the full turn and IPU pitch partner difference vectors.
normMeanPitchPartnerDiffVec = [];
normMaxPitchPartnerDiffVec = [];
normMinPitchPartnerDiffVec = [];

% And do the same for intensities.
normMeanIntensityPartnerDiffVec = [];
normMaxIntensityPartnerDiffVec = [];
normMinIntensityPartnerDiffVec = [];


% Also allow the mean pitch and intensity partner difference vectors to 
% have negative values.  This will be used to visualize the data.
normNegMeanPitchPartnerDiffVec = [];
normNegMeanIntensityPartnerDiffVec = [];

% Produce the partner differences in a loop over the turns.
for Pindx = 1:length(Pr)
    
    % Pitch mean
    normMeanPitchPartnerDiffVec = [normMeanPitchPartnerDiffVec; abs(Pr(Pindx).thisNormPitchMean - Pr(Pindx).nextNormPitchMean)];
    % Pitch max
    normMaxPitchPartnerDiffVec = [normMaxPitchPartnerDiffVec; abs(Pr(Pindx).thisNormPitchMax - Pr(Pindx).nextNormPitchMax)];
    % Pitch min
    normMinPitchPartnerDiffVec = [normMinPitchPartnerDiffVec; abs(Pr(Pindx).thisNormPitchMin - Pr(Pindx).nextNormPitchMin)];
    % Negative pitch mean.
    normNegMeanPitchPartnerDiffVec = [normNegMeanPitchPartnerDiffVec; Pr(Pindx).thisNormPitchMean - Pr(Pindx).nextNormPitchMean];

    % Do the same for the intensity variables.
    % Intensity mean.
    normMeanIntensityPartnerDiffVec = [normMeanIntensityPartnerDiffVec; abs(Pr(Pindx).thisNormIntensityMean - Pr(Pindx).nextNormIntensityMean)];
    % Intensity max.
    normMaxIntensityPartnerDiffVec = [normMaxIntensityPartnerDiffVec; abs(Pr(Pindx).thisNormIntensityMax - Pr(Pindx).nextNormIntensityMax)];
    % Intensity min
    normMinIntensityPartnerDiffVec = [normMinIntensityPartnerDiffVec; abs(Pr(Pindx).thisNormIntensityMin - Pr(Pindx).nextNormIntensityMin)];
    % Negative intensity mean.
    normNegMeanIntensityPartnerDiffVec = [normNegMeanIntensityPartnerDiffVec; Pr(Pindx).thisNormIntensityMean-Pr(Pindx).nextNormIntensityMean];
end

%% Calculate the OTHER DIFFERENCES, Levitan Analysis.

% Initialize the other difference vectors.
% Pitch
normMeanPitchOtherDiffVec = [];
normMaxPitchOtherDiffVec = [];
normMinPitchOtherDiffVec = [];
% Intensity
normMeanIntensityOtherDiffVec = [];
normMaxIntensityOtherDiffVec = [];
normMinIntensityOtherDiffVec = [];


for Pindx = 1:length(Pr)

    % Initialize the random sum variables.
    meanPitchSum = [];
    maxPitchSum = [];
    minPitchSum = [];
    meanIntensitySum = [];
    maxIntensitySum = [];
    minIntensitySum = [];
  

    for s = 1:10
    
        % Pitch.
        meanPitchSum = [meanPitchSum; abs(Pr(Pindx).thisNormPitchMean - randsample(nextNormMeanPitchVec, 1))];
        maxPitchSum = [maxPitchSum; abs(Pr(Pindx).thisNormPitchMax - randsample(nextNormMaxPitchVec, 1))];
        minPitchSum = [minPitchSum; abs(Pr(Pindx).thisNormPitchMin - randsample(nextNormMinPitchVec, 1))];
        % Intensity.
        meanIntensitySum = [meanIntensitySum; abs(Pr(Pindx).thisNormIntensityMean - randsample(nextNormMeanIntensityVec, 1))];
        maxIntensitySum = [maxIntensitySum; abs(Pr(Pindx).thisNormIntensityMax - randsample(nextNormMaxIntensityVec, 1))];
        minIntensitySum = [minIntensitySum; abs(Pr(Pindx).thisNormIntensityMin - randsample(nextNormMinIntensityVec, 1))];
    
    end

    % Add the means of the random sums to the other difference vectors.
    % Pitches.
    normMeanPitchOtherDiffVec = [normMeanPitchOtherDiffVec; mean(meanPitchSum)];
    normMaxPitchOtherDiffVec = [normMaxPitchOtherDiffVec; mean(maxPitchSum)];
    normMinPitchOtherDiffVec = [normMinPitchOtherDiffVec; mean(minPitchSum)];
    % Intensities.
    normMeanIntensityOtherDiffVec = [normMeanIntensityOtherDiffVec; mean(meanIntensitySum)];
    normMaxIntensityOtherDiffVec = [normMaxIntensityOtherDiffVec; mean(maxIntensitySum)];
    normMinIntensityOtherDiffVec = [normMinIntensityOtherDiffVec; mean(minIntensitySum)];

end



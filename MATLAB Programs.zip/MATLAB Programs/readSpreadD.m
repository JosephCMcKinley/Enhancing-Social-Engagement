%readSpreadD.m
%read all worksheets from one xlsx spreadsheet.
%and put them into struct S
%This version saves in S(nn).rawsheet but SKIPs empty sheets


%% read spreadsheet, set up vars

fileName = "Final_Social_Engagement_Excel_Data_Rater_2.xlsx";

oldSheetNames = sheetnames(fileName); %names of the worksheets at bottom
%  but some of them may be empty like "Sheet1"
clear newSheetNames;
 %a 


%% get rid of a few empty sheets
warning('off','all'); %suppress verbose warning about variable names
cntGood = 0;
sheetNumList = [];
for ii = 1 : length(oldSheetNames)
    sheetNam = oldSheetNames(ii); %this sheetNam may not be good.
    %if isempty(sheetData)readtable(fileName,'Sheet',sheetNam) %like 'Sheet1"
    x = char(sheetNam); x = x(1:3);
    if strcmp(x,'She')
        msg = ['bad sheet',sheetNam]
        continue %skip this pseudo-worksheet with no data
        %but could put it on a list in S2( )
    end
    cntGood = cntGood+1;
    sheetNumList = [sheetNumList;cntGood]; 
    newSheetNames(cntGood) = oldSheetNames(ii ); 

end

%warning('on','all');


%% Put spreadsheet data into struct S:
clear S
for sheetNum = 1:length(sheetNumList)
    Xtable = readtable(fileName,'Sheet',sheetNum);
    S(sheetNum).Xtable = Xtable;
    S(sheetNum).sheetNum = sheetNum; %not necessary
    S(sheetNum).sheetNum = newSheetNames(sheetNum);
    varNames = Xtable.Properties.VariableNames;
    S(sheetNum).varNames =varNames;
end

clear S2
S2.fileName = fileName;
S2.newSheetNames = newSheetNames;
S2.oldSheetNames = oldSheetNames; 


%% turn warnings back on after reading spreadsheets
warning('on','all');
msg = ['Struct S has been created with blah worksheets.']
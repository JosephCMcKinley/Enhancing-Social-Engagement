%diarPutCurvesAndWhoIntoMatrix.m
%After running readPraatPitchTierOOB.m and diarReadFileMakeDstruct.m
%   to make the D struct based on "who",
% run this pgm to get the pitch curve for the time range in eacah
%  diarized interval and insert pitch stats into matrix M:
% M(intv,1) = intv number (for easier analysis and perusing later)
% M(intv,2) = person 'Who' as a number
%              1 = "YF", 2 = "OF", 3 = "OM", etc.
% M(intv,3) = mean pitch
% M(intv,4) = startTime (seconds)
% M(intv,5) = endTime
% M(intv,6) = median pitch
% M(intv,7) = slope
% M(intv,8) = magic category/classification (not implemented yet)


%% set up WhoDict,including bad values of whoTxt
% the "Who" (speaker) codes:
% YF  OF  OM  SO  N silence
%WhoDict = dictionary("YF",1,"OF",2,"OM",3,"SO",4,"N",5,"silent",6,"L",7,"sounding",8,"badWho",9);

% loop through all intervals in D struct, build the matrix M
numIntervals = length(D); %diarized info 'intervals'
M = zeros(numIntervals,9);
for intv = 1:numIntervals %loop thru each item (interval) in D struct
    xmin = D(intv).xmin; xmax = D(intv).xmax; %start and end times for this intv
    %pitches = dataVals(timeVals >= xmin & timeVals <= xmax);
    ff = find(pitchTimes>=xmin & pitchTimes <= xmax); %see old way too
    pitches = pitchVals(ff);
    %pitches above is vector of pitches for this one intv item in T struct.
    msg = 'debug';
    if isempty(pitches)
        %continue %ignore this item  what about Who?
        pitches = 0;
    end

    whoTxt = D(intv).txtWho;

    if isKey(WhoDict,whoTxt) 
        whoNum = WhoDict(whoTxt);
    else
    whoNum = 9; % bad or missing whoTxt for this interval
    end

    M(intv,1) = intv;
    M(intv,2) = whoNum;
    M(intv,3) = mean(pitches);
    M(intv,4) = xmin; %start time for this Interval
    M(intv,5) = xmax;
    M(intv,6) = median(pitches);
    M(intv,7) = std(pitches) ; %standard deviation
    M(intv,8) = skewness(pitches); %skewness
    
end

skew = M(:, 8);

%% show a sample histogram:
whoNum = 1; % "YF"
whoNum = 2; % "OF"
whoNum = 3; % "OF"
theList = find(M(:,2) == whoNum);
thePitches = M(theList,3);
%figure(200); clf
%histogram(thePitches)

%% make a table
%t = array2table(X,'VariableNames',{'x' 'y' 'z'});
begI = 2; endI = 100;
mm = M(begI:2:endI,1:6);
myTable = array2table(mm,'VariableNames', {'Indx','Who','meanP','begT','endT','median'});

%plot(nonzeros(M(12:2:36, 3)))


%plot(linspace(1947, 1990, 19), nonzeros(M(1947:2:1990, 3)))


%plot(nonzeros(M(1:200, 3)))

%mean(nonzeros(M(12:2:36, 3)))
%mean(nonzeros(M(1947:2:1990, 3)))

%readPraatPitchTierOOB.m

% Read in a Praat 'pitch tier' file. But not an intensity tier
% create arrays pitchTimes(ii) and corresponding pitchVals(ii) .
% ii 'points" are not continuous.

% Then optionally graph the pitch values (y) vs times (x).
% Note that the pitch values are often discontinuous in time.

%filename = '4_11_21_Pitch_Tier' %for first diarization test
%pitchTierFile = '4_16_21_Pitch_Tier';

%% Read the exported Praat file into MATLAB:'
textLines = readlines(pitchTierFile);
objectClass = textLines(2) %show what kind of tier this is
numberOfLines = length(textLines)

%% show TYPICAL beginning of the data:
% "File type = "ooTextFile""
%     "Object class = "PitchTier""
%     ""
%     "xmin = 0 "
%     "xmax = 481 "
%     "points: size = 14311 "
%     "points [1]:"  %this is text line 7
%     "    number = 0.09821428571428165 "
%     "    value = 253.28927498886804 "
%     "points [2]:"
%     "    number = 0.10892857142856738 "
%     "    value = 255.8167689865122 "
%     "points [3]:"
%     "    number = 2.5517857142857103 "
   
%% Get the number of points, etc:
stg = textLines(4);
startTime = numberize(stg);
stg = textLines(5); %should be xmax = 0,or simila
maxTime = numberize(stg) %my convenience function
stg = textLines(6); % like "points: size = 14311 "
x = split(stg,'='); x2 = x(2);
numPoints = str2num(x2);
pitchTimes = zeros(numPoints,1); %pre-allocate for speed
pitchVals = zeros(numPoints,1);

%% loop through all the points
startLine = 7;
offset = 5;
for pt = 1:numPoints
    stg1 = textLines(offset  + pt*3); %this is time as txt
    numb = numberize(stg1);
    pitchTimes(pt)= numb;
    stg2 = textLines(offset+ 1 +pt*3); %value of the data
    pitchVals(pt) = numberize(stg2); %this is Pitch values
end

%% show the data:
if 0 %plotting turned off for now
figure(1); clf
plot(timeVals,pitchVals,'.-'); zoom xon; grid minor
figure(2); clf
plot(timeVals,pitchVals,'*'); zoom xon
grid minor
niceTitle = strrep(filename,'_',' '); %the "_" sucks in title
niceTitle = strcat("pitchVals for ",niceTitle);
title(niceTitle)
end

%% function to get number out of stgInp = numberValue
function numb = numberize(stgInp)
numb = extractAfter(stgInp,"=");
numb = double(numb);
end

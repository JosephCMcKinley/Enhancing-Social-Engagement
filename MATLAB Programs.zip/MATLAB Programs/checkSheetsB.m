%checkSheetsB.m
%go through structure S and check for various errors
%clearvars -except S S2


%% stuff
numSheets = length(S);
firstEventCol= 5;
lastEventCol = 19; %this is actually the "Engage" core column
firstTextCol = 1;
lastTextCol = 3;
sheetNames = S2.newSheetNames';

for iSheet = 1:numSheets
    Xtable = S(iSheet).Xtable;
    varNames = Xtable.Properties.VariableNames; %SAME FOR ALL SHEETS?
    nRows = height(Xtable); %these are data rows, not headings,etc.
    Mtrx = zeros(nRows,19); %15 is number of Event columns
    msg = ['Checking sheet ',num2str(iSheet),'  ',sheetNames(iSheet)];
    disp(msg)

    for iCol  = 5:19
        oneCol = Xtable(:,iCol);
        oneCol2 = table2array(oneCol);
        if ~isnumeric(oneCol2)
            msg =strcat("  Column ",num2str(iCol),"  non-numeric");
            disp(msg)
        else
            Mtrx(:,iCol) = double(oneCol2);
        end
    end
    S(iSheet).Mtrx = Mtrx;


    %function [begTime,endTime] = time2mins(beg2EndTime)
    %timeString = Xtable(1,4);
    %begTime = 
    %[begTim,endTime] = time2mins(timeString);

end


clear A

meanPitchScores = [];
maxPitchScores = [];
minPitchScores = [];

meanIntensityScores = [];
maxIntensityScores = [];
minIntensityScores = [];

%thisvideoAcousticData = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 4)), :);
%thisbehavioralDataMatrix = S(4).Mtrx;

for s = 1:length(S)

    behavioralDataMatrix = S(s).Mtrx;
    timeDataMatrix = finalTimeDataMatrix((find(finalTimeDataMatrix(:, 1) == s)), :);

    for e = 1:size(behavioralDataMatrix, 1)
    
        pairStartTimes = [];
        pairEndTimes = [];

        meanPitchScore = [];
        maxPitchScore = [];
        minPitchScore = [];

        meanIntensityScore = [];
        maxIntensityScore = [];
        minIntensityScore = [];

        for g = 1:length(timeDataMatrix)

            if ((behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(timeDataMatrix(g, 3)) <= behavioralDataMatrix(e, 6))||...
               ((timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 5))&(behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 3))&(timeDataMatrix(g, 3)) <= behavioralDataMatrix(e, 6))||...
               (behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 6))&(behavioralDataMatrix(e, 6) <= timeDataMatrix(g, 3))
                
               meanPitchScore = [meanPitchScore; timeDataMatrix(g, 5)];
               maxPitchScore = [maxPitchScore; timeDataMatrix(g, 6)];
               minPitchScore = [minPitchScore; timeDataMatrix(g, 7)];

               meanIntensityScore = [meanIntensityScore; timeDataMatrix(g, 8)];
               maxIntensityScore = [maxIntensityScore; timeDataMatrix(g, 9)];
               minIntensityScore = [minIntensityScore; timeDataMatrix(g, 10)];

            end    
        end

        
        A(e).pitchMeans = meanPitchScore;
        A(e).pairStartTimes = pairStartTimes;
        A(e).pairEndTimes = pairEndTimes;
        A(e).eventStartTimes = behavioralDataMatrix(e, 5);
        A(e).eventEndTimes = behavioralDataMatrix(e, 6);
    


        meanPitchScores = [meanPitchScores; mean(diff(meanPitchScore))];
        maxPitchScores = [maxPitchScores; mean(diff(maxPitchScore))];
        minPitchScores = [minPitchScores; mean(diff(minPitchScore))];
        
        meanIntensityScores = [meanIntensityScores; mean(diff(meanIntensityScore))];
        maxIntensityScores = [maxIntensityScores; mean(diff(maxIntensityScore))];
        minIntensityScores = [minIntensityScores; mean(diff(minIntensityScore))];

    end

end

%stest = S(1).Mtrx


%test = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 1)), :)

%test2 = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 2)), :)

%test4 = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 4)), :)




%meanPitchScores(isnan(meanPitchScores)) = [];

%maxPitchScores(isnan(maxPitchScores)) = [];

%minPitchScores(isnan(minPitchScores)) = [];

%meanIntensityScores(isnan(meanIntensityScores)) = [];

%maxIntensityScores(isnan(maxIntensityScores)) = [];

%minIntensityScores(isnan(minIntensityScores)) = [];
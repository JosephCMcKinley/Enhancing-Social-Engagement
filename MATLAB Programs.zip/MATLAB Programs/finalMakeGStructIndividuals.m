%XagglomPitchB.m
%Scan thru D (Diarization) struct to combine nearby curvelets
%  with the SAME Who. Also gets the times in G.timeList.
% Creates structure G for aGGlomeration of pitches
%  for the same adjacent whoNums in the diarization.

%  G struct has for each Group:
%  G(Gindx).variousThings:
%   .whoNum = which whoNum for this whole group
%   .longPitchVec = concat of little pitches 
%   .timeList= concat of corresponding times for longPitchVec

% Logic: s through all Dindx in D struct
%Only whoNums 1,2,3 are "Good." (change this.)
%variable "currentGoodWho" is maintained. It's init to 0.
%Pseudocode:
%Step thru Dindxes.  If its whoNum is good (1,2,3), then:
%   If this Who is Good, and is  NOT equal to currentGoodWho,
%  then:  set currentGoodWho = this whoNum,  and
%        increment Gindx, and
%       Set G(Gindx).longPitchVec = this pitch Vec. 
%       Also set G(Gindx).timeList= 
%       continue the loop to go on to next Dindx.
%  If Who is Good and IS equal to currentGoodWho, then:
%     Concat its vec onto G(Gindx).longPitchVec
%     So this strings together "adjacent" pitch vecs
%        with same whoNum.

%% initialize variables:
Dlen = length(D);
clear G %group struct
Gindx  = 0; %this will count the groups
currentGoodWho = 0;
Dindx = 0;

%% loop thru D struct and add to 
for Hindx = 1:Dlen
    thisPitchVec = D(Hindx).pitchList;
    thisNormPitchVec = D(Hindx).normPitchList;
    thisIntensityVec = D(Hindx).intensityList;
    thisNormIntensityVec = D(Hindx).normIntensityList;
    thisLinearIntensityVec = D(Hindx).linearIntensityList;
    thisTimes = D(Hindx).pitchTimeList; %new feature, see mainRun
    thisIntensityTimes = D(Hindx).intensityTimeList;
    if isempty(thisPitchVec) %SKIP diar items with no pitch
        continue %SKIP this pitchless item
    end

    hoo = D(Hindx).whoNum;
 
    if hoo <= 18 && hoo ~= currentGoodWho %May need new group
        currentGoodWho = hoo;
        Gindx = Gindx+1;
        %thisVec = D(Hindx).pitchList; %was already set above.
        G(Gindx).longPitchVec = thisPitchVec; %a nice new Gindx
        G(Gindx).normLongPitchVec = thisNormPitchVec;
        G(Gindx).longIntensityVec = thisIntensityVec;
        G(Gindx).normLongIntensityVec = thisNormIntensityVec;
        G(Gindx).longLinearIntensityVec = thisLinearIntensityVec;
        G(Gindx).longTimeVec = thisTimes; 
        G(Gindx).longIntensityTimeVec = thisIntensityTimes;
        G(Gindx).whoNum = hoo;%
        %do same for TIMES here MUST ADD TO D struct
        %Joseph: Not sure if your version already puts 
        % the time for each pitch value into the D struct.
        continue % go on to next Hindx

    elseif hoo <= 18 && hoo == currentGoodWho %another in this group
        G(Gindx).longPitchVec = [G(Gindx).longPitchVec;thisPitchVec];
        G(Gindx).normLongPitchVec = [G(Gindx).normLongPitchVec;thisNormPitchVec];
        G(Gindx).longIntensityVec = [G(Gindx).longIntensityVec; thisIntensityVec];
        G(Gindx).normLongIntensityVec = [G(Gindx).normLongIntensityVec; thisNormIntensityVec];
        G(Gindx).longLinearIntensityVec = [G(Gindx).longLinearIntensityVec; thisLinearIntensityVec];
        G(Gindx).longTimeVec = [G(Gindx).longTimeVec;thisTimes];
        G(Gindx).longIntensityTimeVec = [G(Gindx).longIntensityTimeVec;thisIntensityTimes];
        continue %go on to next Hindx, we're done here, folks

    else
        %currentGoodWho = hoo; %start a new Group
        %Gindx = Gindx+1;
        %thisPitchVec = D(Hindx).pitchList;
        %G(Gindx).longPitchVec = thisPitchVec;
        %G(Gindx).stdLongPitchVec = thisStandardPitchVec;
        %G(Gindx).longIntensityVec = thisIntensityVec;
        %G(Gindx).stdLongIntensityVec = thisStandardIntensityVec;
        %G(Gindx).longLinearIntensityVec = thisLinearIntensityVec;
        %G(Gindx).longTimeVec = thisTimes;
        %do same for timelist here.
        %No need to 'continue' here because no logic below
        continue
    end
end

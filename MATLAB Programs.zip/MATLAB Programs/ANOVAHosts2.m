rng(1)

H1ResponseData = engagementScores(host1Data == 1);
H2ResponseData = engagementScores(host2Data == 1);
H3ResponseData = engagementScores(host3Data == 1);
H4ResponseData = engagementScores((host1Data == 0)&(host2Data == 0)&(host3Data == 0));

downsampleH1 = datasample(H1ResponseData, 117);
downsampleH2 = datasample(H2ResponseData, 117);
downsampleH3 = datasample(H3ResponseData, 117);

anotherDownSampleH1 = datasample(H1ResponseData, 399);
anotherDownSampleH2 = datasample(H2ResponseData, 399);

ANOVAEngagementDataMatrix1 = cat(2, downsampleH1, downsampleH2);
ANOVAEngagementDataMatrix2 = cat(2, ANOVAEngagementDataMatrix1, downsampleH3);

ANOVAEngagementDataMatrix3 = cat(2, anotherDownSampleH1, anotherDownSampleH2);


ANOVAFourHosts = cat(2, ANOVAEngagementDataMatrix2, H4ResponseData);
ANOVAThreeHosts = cat(2, ANOVAEngagementDataMatrix3, H3ResponseData);


[p,tbl,stats] = anova1(ANOVAEngagementDataMatrix2);

[p,tbl,stats1] = anova1(ANOVAEngagementDataMatrix3);


[c,m,h,nms] = multcompare(stats,'alpha',0.05,'ctype','hsd');

[c,m,h,nms] = multcompare(stats1,'alpha',0.05,'ctype','hsd');




figure;
subplot(2,2,1);
h = histogram(H1ResponseData, "Normalization","probability");
title('Host 1');
xlabel('Engagement Scores');
ylabel('Percentage of Scores');

subplot(2,2,2);
h = histogram(H2ResponseData, "Normalization","probability");
title('Host 2');
xlabel('Engagement Scores');
ylabel('Percentage of Scores');

subplot(2,2,3) %get the count with hist
h = histogram(H3ResponseData, "Normalization","probability");
title('Host 3');
xlabel('Engagement Scores');
ylabel('Percentage of Scores');

subplot(2,2,4)
h = histogram(H4ResponseData, "Normalization","probability");
title('Host 4');
xlabel('Engagement Scores');
ylabel('Percentage of Scores');
%% Statistical tests based on Levitan's work. 
% 
% 
%  Now TEST FOR INDEPENDENCE BETWEEN PARTNER DIFF, OTHER DIFF
%  First, test TURN LEVEL PROXIMITY.

[h11,p11,ci11,stats11] = ttest(normMeanPitchPartnerDiffVec, normMeanPitchOtherDiffVec);
[h12,p12,ci12,stats12] = ttest(normMaxPitchPartnerDiffVec, normMaxPitchOtherDiffVec);
[h13,p13,ci13,stats13] = ttest(normMinPitchPartnerDiffVec, normMinPitchOtherDiffVec);
[h14,p14,ci14,stats14] = ttest(normMeanIntensityPartnerDiffVec, normMeanIntensityOtherDiffVec);
[h15,p15,ci15,stats15] = ttest(normMaxIntensityPartnerDiffVec, normMaxIntensityOtherDiffVec);
[h16,p16,ci16,stats16] = ttest(normMinIntensityPartnerDiffVec, normMinIntensityOtherDiffVec);



%% Compute the TURN-AT-TALK CORRELATION for each feature.

%[hFull,pFull,ciFull,statsFull] = ttest(fullFirstHalfPitches, fullSecondHalfPitches);

% This measures TURN LEVEL SYNCHRONY.
% Pearson correlation.

% First test by comparing with the mean over the entire speaker's portion
% of the turn.
[r21, p21] = corr(thisNormMeanPitchVec, nextNormMeanPitchVec);
[r22, p22] = corr(thisNormMaxPitchVec, nextNormMaxPitchVec);
[r23, p23] = corr(thisNormMinPitchVec, nextNormMinPitchVec);
[r24, p24] = corr(thisNormMeanIntensityVec, nextNormMeanIntensityVec);
[r25, p25] = corr(thisNormMaxIntensityVec, nextNormMaxIntensityVec);
[r26, p26] = corr(thisNormMinIntensityVec, nextNormMinIntensityVec);



%% Append the statistics vectors to collect the data for the videos.
%  They will be put into tables.

% First, create vectors for the Levitan analysis results.

% Levitan: turn-level proximity data.
% Need each video's p-values, t-statistics, and degrees of freedom.
P11 = [P11; p11];
T11 = [T11; stats11.tstat];
DF11 = [DF11; stats11.df];
P12 = [P12; p12];
T12 = [T12; stats12.tstat];
DF12 = [DF12; stats12.df];
P13 = [P13; p13];
T13 = [T13; stats13.tstat];
DF13 = [DF13; stats13.df];
P14 = [P14; p14];
T14 = [T14; stats14.tstat];
DF14 = [DF14; stats14.df];
P15 = [P15; p15];
T15 = [T15; stats15.tstat];
thisDF15 = stats15.df;
DF15 = [DF15; thisDF15];
P16 = [P16; p16];
T16 = [T16; stats16.tstat];
DF16 = [DF16; stats16.df];


%% Levitan: turn-level synchrony data.
% Need each video's p-values and r-values.
    
P21 = [P21; p21];
R21 = [R21; r21];
P22 = [P22; p22];
R22 = [R22; r22];
P23 = [P23; p23];
R23 = [R23; r23];
P24 = [P24; p24];
R24 = [R24; r24];
P25 = [P25; p25];
R25 = [R25; r25];
P26 = [P26; p26];
R26 = [R26; r26];
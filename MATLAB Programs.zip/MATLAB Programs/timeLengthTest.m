hostTimeLength = [];
participantTimeLength = [];
controlTimeLength = [];


for gidx = 1:length(G)
    
    if G(gidx).whoNum == 1
        
        hostTimeLength = [hostTimeLength; G(gidx).longTimeVec(end) - G(gidx).longTimeVec(1)];
    
    elseif G(gidx).whoNum == 2 

        controlTimeLength = [controlTimeLength; G(gidx).longTimeVec(end) - G(gidx).longTimeVec(1)];

    elseif G(gidx).whoNum == 3||G(gidx).whoNum == 4||G(gidx).whoNum == 5||G(gidx).whoNum == 6||G(gidx).whoNum == 7||...
            G(gidx).whoNum == 8||G(gidx).whoNum == 9||G(gidx).whoNum == 10||G(gidx).whoNum == 11||G(gidx).whoNum == 12||...
            G(gidx).whoNum == 13||G(gidx).whoNum == 14||G(gidx).whoNum == 15||G(gidx).whoNum == 16||G(gidx).whoNum == 17||G(gidx).whoNum == 18

        participantTimeLength = [participantTimeLength; G(gidx).longTimeVec(end) - G(gidx).longTimeVec(1)];
    end
end

hostTotalTime = sum(hostTimeLength);

controlTotalTime = sum(controlTimeLength);

participantTotalTime = sum(participantTimeLength);

participantPercentage = sum(participantTimeLength)/(hostTotalTime + controlTotalTime + participantTotalTime);

hostPercentage = sum(hostTimeLength)/(hostTotalTime + controlTotalTime + participantTotalTime);

controlPercentage = sum(controlTimeLength)/(hostTotalTime + controlTotalTime + participantTotalTime);
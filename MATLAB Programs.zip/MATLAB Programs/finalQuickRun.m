%% Final quick run.  Performs all the analyses for a single video.

tic,

if 1
    clear
end

%% Set the files to be analyzed.  Here, we only do one recording. 

pitchTierFile = '5_19_21_Pitch_Tier';

intensityTierFile = '5_19_21_Intensity_Tier';

diarizationFile = '5_19_21_Full_Diarization_Individuals_H1';

%% Set the who dictionary.

finalMakeWhoDictionaryIndividuals

finalInitializeDataVectors

%% Read the files in.

% Get pitchTimes and pitchVals.
readPraatPitchTierOOB 
    
% Get intensitiesTimes, intensitiesVals, cleanIntensities,
% linearIntensities.
readPraatIntensityTierOOB

%% Preprocess the data.

% Makes the pitch and intensity data struct.
makeXStruct 
    
% Makes the diarization D struct with text field info.
diarReadFileMakeDstruct 
    
% Converts the D struct into a numerical matrix for data analysis.
diarPutCurvesAndWhoIntoMatrix

finalDataNormalizationIndividuals

% Agglomarates the pitch tiers by speaker identity to form turns.
finalMakeGStructIndividuals

% Produces the pair structure.
finalMakePrStruct

finalPrepareDataForAnalysis

finalLevitanAnalysis

toc
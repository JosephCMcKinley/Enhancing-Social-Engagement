%% Final MainRun program.  

% Run all the analyses.

tic,

%% Read the file names for the pitch tiers, intensity tiers, and 
%  diarization logs to be read in.  Here, we do everything.

finalVideoDataLabels


%% Set the dictionary of speaker groups (H, C, FP, MP, SO, etc.)
%  i.e., get the labels for the diarization intervals.  

finalMakeWhoDictionaryIndividuals


%% Initialize the data vectors, including the Levitan data vectors.

finalInitializeDataVectors


%% Read in the behavioral data from Excel.

% Read in the excel data spreadsheet.
readSpreadD

% Check the spreadsheet to see that all the data entries are correct and 
% create the behavioral data matrix.
checkSheetsB


%% Run a single loop over all the video files and apply data preprocessing
%  and analysis.

% Set up the loop to go over all videos.
for idx = 1:length(pitchTiers)

    pitchTierFile = pitchTiers(idx);
    intensityTierFile = intensityTiers(idx);
    diarizationFile = diarizationLogs(idx);

    % Run the programs to set up the data and perorm the analyses.
    % Get pitchTimes and pitchVals.
    readPraatPitchTierOOB 
    
    % Get intensitiesTimes, intensitiesVals, cleanIntensities,
    % linearIntensities.
    readPraatIntensityTierOOB
    
    % Makes the pitch and intensity data struct X.
    makeXStruct
    
    % Makes the diarization D struct with text field info.
    diarReadFileMakeDstruct 
    
    % Converts the D struct into a numerical matrix for data analysis.
    diarPutCurvesAndWhoIntoMatrix

    % Normalize the pitch and intensity data for the different speaker 
    % groups, and produce pitch and intensity histograms.
    finalDataNormalizationIndividuals

    % Agglomarates the pitch tiers by speaker identity to form turns.
    finalMakeGStructIndividuals

    % Put all the acoustic data into a Pr Struct.
    finalMakePrStruct

    % Prepares the data for the Levitan analysis.
    finalPrepareDataForAnalysis

    % Perform the Levitan analysis for a single video.
    finalLevitanAnalysis

    %finalAppendLevitanVectors

    timeLengthTest

    makeTimeDataMatrix

    videoPairNumberVec = [videoPairNumberVec; length(Pr)];
    
    allTimeLengthVec = [allTimeLengthVec; participantTotalTime];

    allParticipantPercentTimeSpokenVec = [allParticipantPercentTimeSpokenVec; participantPercentage];

    allHostPercentTimeSpokenVec = [allHostPercentTimeSpokenVec; hostPercentage];

    allControlPercentTimeSpokenVec = [allControlPercentTimeSpokenVec; controlPercentage];
end 


% Run the time data analysis.  This gives us the time data used in the 
% linear regression model.
timeAnalysis2

acousticAnalysis2

finalModelFitting

levitanTableProgram

%ANOVAHosts2

%plot(allParticipantPercentTimeSpokenVec)

toc


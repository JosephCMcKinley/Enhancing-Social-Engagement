%% Normalize the data to be added to the D struct.


%  Create a list that gives the diarization indices for each speaker.
%  Need to run diarPutCurvesAndWhoIntoMatrix to create the M matrix first.

listH = find(M(:, 2) == 1);
listC = find(M(:, 2) == 2);

listF1 = find(M(:, 2) == 3);
listF2 = find(M(:, 2) == 4);
listF3 = find(M(:, 2) == 5);
listF4 = find(M(:, 2) == 6);
listF5 = find(M(:, 2) == 7);
listF6 = find(M(:, 2) == 8);
listF7 = find(M(:, 2) == 9);
listF8 = find(M(:, 2) == 10);
listF9 = find(M(:, 2) == 11);

listM1 = find(M(:, 2) == 12);
listM2 = find(M(:, 2) == 13);
listM3 = find(M(:, 2) == 14);
listM4 = find(M(:, 2) == 15);
listM5 = find(M(:, 2) == 16);
listM6 = find(M(:, 2) == 17);
listM7 = find(M(:, 2) == 18);



%% Create vectors of all the pitches corresponding to each speaker.

% Host.
allPitchesH = [];
for indx = 1:length(listH)
    newPitchH = D(listH(indx)).pitchList;
    allPitchesH = [allPitchesH; newPitchH];
end

% Control.
allPitchesC = [];
for indx = 1:length(listC)
    newPitchC = D(listC(indx)).pitchList;
    allPitchesC = [allPitchesC; newPitchC];  
end


% Female 1.
allPitchesF1 = [];
for indx = 1:length(listF1)
    newPitchF1 = D(listF1(indx)).pitchList;
    allPitchesF1 = [allPitchesF1; newPitchF1];
end

% Female 2.
allPitchesF2 = [];
for indx = 1:length(listF2)
    newPitchF2 = D(listF2(indx)).pitchList;
    allPitchesF2 = [allPitchesF2; newPitchF2];
end

% Female 3.
allPitchesF3 = [];
for indx = 1:length(listF3)
    newPitchF3 = D(listF3(indx)).pitchList;
    allPitchesF3 = [allPitchesF3; newPitchF3];
end

% Female 4.
allPitchesF4 = [];
for indx = 1:length(listF4)
    newPitchF4 = D(listF4(indx)).pitchList;
    allPitchesF4 = [allPitchesF4; newPitchF4];
end

% Female 5.
allPitchesF5 = [];
for indx = 1:length(listF5)
    newPitchF5 = D(listF5(indx)).pitchList;
    allPitchesF5 = [allPitchesF5; newPitchF5];
end

% Female 6.
allPitchesF6 = [];
for indx = 1:length(listF6)
    newPitchF6 = D(listF6(indx)).pitchList;
    allPitchesF6 = [allPitchesF6; newPitchF6];
end

% Female 7.
allPitchesF7 = [];
for indx = 1:length(listF7)
    newPitchF7 = D(listF7(indx)).pitchList;
    allPitchesF7 = [allPitchesF7; newPitchF7];
end

% Female 8.
allPitchesF8 = [];
for indx = 1:length(listF8)
    newPitchF8 = D(listF8(indx)).pitchList;
    allPitchesF8 = [allPitchesF8; newPitchF8];
end

% Female 9.
allPitchesF9 = [];
for indx = 1:length(listF9)
    newPitchF9 = D(listF9(indx)).pitchList;
    allPitchesF9 = [allPitchesF9; newPitchF9];
end


% Male 1.
allPitchesM1 = [];
for indx = 1:length(listM1)
    newPitchM1 = D(listM1(indx)).pitchList;
    allPitchesM1 = [allPitchesM1; newPitchM1];  
end

% Male 2.
allPitchesM2 = [];
for indx = 1:length(listM2)
    newPitchM2 = D(listM2(indx)).pitchList;
    allPitchesM2 = [allPitchesM2; newPitchM2];  
end

% Male 3.
allPitchesM3 = [];
for indx = 1:length(listM3)
    newPitchM3 = D(listM3(indx)).pitchList;
    allPitchesM3 = [allPitchesM3; newPitchM3];  
end

% Male 4.
allPitchesM4 = [];
for indx = 1:length(listM4)
    newPitchM4 = D(listM4(indx)).pitchList;
    allPitchesM4 = [allPitchesM4; newPitchM4];  
end

% Male 5.
allPitchesM5 = [];
for indx = 1:length(listM5)
    newPitchM5 = D(listM5(indx)).pitchList;
    allPitchesM5 = [allPitchesM5; newPitchM5];  
end

% Male 6.
allPitchesM6 = [];
for indx = 1:length(listM6)
    newPitchM6 = D(listM6(indx)).pitchList;
    allPitchesM6 = [allPitchesM6; newPitchM6];  
end

% Male 7.
allPitchesM7 = [];
for indx = 1:length(listM7)
    newPitchM7 = D(listM7(indx)).pitchList;
    allPitchesM7 = [allPitchesM7; newPitchM7];  
end



%% Compute some basic statistics of the pitch data for normalization.


% Drop all the zeros so that they don't mess up the statistics
noZeroPitchesH = nonzeros(allPitchesH);
noZeroPitchesC = nonzeros(allPitchesC);

noZeroPitchesF1 = nonzeros(allPitchesF1);
noZeroPitchesF2 = nonzeros(allPitchesF2);
noZeroPitchesF3 = nonzeros(allPitchesF3);
noZeroPitchesF4 = nonzeros(allPitchesF4);
noZeroPitchesF5 = nonzeros(allPitchesF5);
noZeroPitchesF6 = nonzeros(allPitchesF6);
noZeroPitchesF7 = nonzeros(allPitchesF7);
noZeroPitchesF8 = nonzeros(allPitchesF8);
noZeroPitchesF9 = nonzeros(allPitchesF9);

noZeroPitchesM1 = nonzeros(allPitchesM1);
noZeroPitchesM2 = nonzeros(allPitchesM2);
noZeroPitchesM3 = nonzeros(allPitchesM3);
noZeroPitchesM4 = nonzeros(allPitchesM4);
noZeroPitchesM5 = nonzeros(allPitchesM5);
noZeroPitchesM6 = nonzeros(allPitchesM6);
noZeroPitchesM7 = nonzeros(allPitchesM7);


% Compute the mean pitch of each speaker over the entire video
meanPitchH = mean(noZeroPitchesH);
meanPitchC = mean(noZeroPitchesC);

meanPitchF1 = mean(noZeroPitchesF1);
meanPitchF2 = mean(noZeroPitchesF2);
meanPitchF3 = mean(noZeroPitchesF3);
meanPitchF4 = mean(noZeroPitchesF4);
meanPitchF5 = mean(noZeroPitchesF5);
meanPitchF6 = mean(noZeroPitchesF6);
meanPitchF7 = mean(noZeroPitchesF7);
meanPitchF8 = mean(noZeroPitchesF8);
meanPitchF9 = mean(noZeroPitchesF9);

meanPitchM1 = mean(noZeroPitchesM1);
meanPitchM2 = mean(noZeroPitchesM2);
meanPitchM3 = mean(noZeroPitchesM3);
meanPitchM4 = mean(noZeroPitchesM4);
meanPitchM5 = mean(noZeroPitchesM5);
meanPitchM6 = mean(noZeroPitchesM6);
meanPitchM7 = mean(noZeroPitchesM7);


% Do the same for the standard deviation.
stdPitchH = std(noZeroPitchesH);
stdPitchC = std(noZeroPitchesC);

stdPitchF1 = std(noZeroPitchesF1);
stdPitchF2 = std(noZeroPitchesF2);
stdPitchF3 = std(noZeroPitchesF3);
stdPitchF4 = std(noZeroPitchesF4);
stdPitchF5 = std(noZeroPitchesF5);
stdPitchF6 = std(noZeroPitchesF6);
stdPitchF7 = std(noZeroPitchesF7);
stdPitchF8 = std(noZeroPitchesF8);
stdPitchF9 = std(noZeroPitchesF9);

stdPitchM1 = std(noZeroPitchesM1);
stdPitchM2 = std(noZeroPitchesM2);
stdPitchM3 = std(noZeroPitchesM3);
stdPitchM4 = std(noZeroPitchesM4);
stdPitchM5 = std(noZeroPitchesM5);
stdPitchM6 = std(noZeroPitchesM6);
stdPitchM7 = std(noZeroPitchesM7);



%% Create vectors of all the intensities corresponding to each speaker.

allIntensitiesH = [];
for indx = 1:length(listH)
    newIntensityH = D(listH(indx)).intensityList;
    allIntensitiesH = [allIntensitiesH; newIntensityH];
end

allIntensitiesC = [];
for indx = 1:length(listC)
    newIntensityC = D(listC(indx)).intensityList;
    allIntensitiesC = [allIntensitiesC; newIntensityC];
end


allIntensitiesF1 = [];
for indx = 1:length(listF1)
    newIntensityF1 = D(listF1(indx)).intensityList;
    allIntensitiesF1 = [allIntensitiesF1; newIntensityF1];
end

allIntensitiesF2 = [];
for indx = 1:length(listF2)
    newIntensityF2 = D(listF2(indx)).intensityList;
    allIntensitiesF2 = [allIntensitiesF2; newIntensityF2];
end

allIntensitiesF3 = [];
for indx = 1:length(listF3)
    newIntensityF3 = D(listF3(indx)).intensityList;
    allIntensitiesF3 = [allIntensitiesF3; newIntensityF3];
end

allIntensitiesF4 = [];
for indx = 1:length(listF4)
    newIntensityF4 = D(listF4(indx)).intensityList;
    allIntensitiesF4 = [allIntensitiesF4; newIntensityF4];
end

allIntensitiesF5 = [];
for indx = 1:length(listF5)
    newIntensityF5 = D(listF5(indx)).intensityList;
    allIntensitiesF5 = [allIntensitiesF5; newIntensityF5];
end

allIntensitiesF6 = [];
for indx = 1:length(listF6)
    newIntensityF6 = D(listF6(indx)).intensityList;
    allIntensitiesF6 = [allIntensitiesF6; newIntensityF6];
end

allIntensitiesF7 = [];
for indx = 1:length(listF7)
    newIntensityF7 = D(listF7(indx)).intensityList;
    allIntensitiesF7 = [allIntensitiesF7; newIntensityF7];
end

allIntensitiesF8 = [];
for indx = 1:length(listF8)
    newIntensityF8 = D(listF8(indx)).intensityList;
    allIntensitiesF8 = [allIntensitiesF8; newIntensityF8];
end

allIntensitiesF9 = [];
for indx = 1:length(listF9)
    newIntensityF9 = D(listF9(indx)).intensityList;
    allIntensitiesF9 = [allIntensitiesF9; newIntensityF9];
end


allIntensitiesM1 = [];
for indx = 1:length(listM1)
    newIntensityM1 = D(listM1(indx)).intensityList;
    allIntensitiesM1 = [allIntensitiesM1; newIntensityM1];
end

allIntensitiesM2 = [];
for indx = 1:length(listM2)
    newIntensityM2 = D(listM2(indx)).intensityList;
    allIntensitiesM2 = [allIntensitiesM2; newIntensityM2];
end

allIntensitiesM3 = [];
for indx = 1:length(listM3)
    newIntensityM3 = D(listM3(indx)).intensityList;
    allIntensitiesM3 = [allIntensitiesM3; newIntensityM3];
end

allIntensitiesM4 = [];
for indx = 1:length(listM4)
    newIntensityM4 = D(listM4(indx)).intensityList;
    allIntensitiesM4 = [allIntensitiesM4; newIntensityM4];
end

allIntensitiesM5 = [];
for indx = 1:length(listM5)
    newIntensityM5 = D(listM5(indx)).intensityList;
    allIntensitiesM5 = [allIntensitiesM5; newIntensityM5];
end

allIntensitiesM6 = [];
for indx = 1:length(listM6)
    newIntensityM6 = D(listM6(indx)).intensityList;
    allIntensitiesM6 = [allIntensitiesM6; newIntensityM6];
end

allIntensitiesM7 = [];
for indx = 1:length(listM7)
    newIntensityM7 = D(listM7(indx)).intensityList;
    allIntensitiesM7 = [allIntensitiesM7; newIntensityM7];
end



%% Compute some basic statistics on the intensity data for normalization.

% Drop all the zeros so that they don't mess up the statistics
noZeroIntensitiesH = nonzeros(allIntensitiesH);
noZeroIntensitiesC = nonzeros(allIntensitiesC);

noZeroIntensitiesF1 = nonzeros(allIntensitiesF1);
noZeroIntensitiesF2 = nonzeros(allIntensitiesF2);
noZeroIntensitiesF3 = nonzeros(allIntensitiesF3);
noZeroIntensitiesF4 = nonzeros(allIntensitiesF4);
noZeroIntensitiesF5 = nonzeros(allIntensitiesF5);
noZeroIntensitiesF6 = nonzeros(allIntensitiesF6);
noZeroIntensitiesF7 = nonzeros(allIntensitiesF7);
noZeroIntensitiesF8 = nonzeros(allIntensitiesF8);
noZeroIntensitiesF9 = nonzeros(allIntensitiesF9);

noZeroIntensitiesM1 = nonzeros(allIntensitiesM1);
noZeroIntensitiesM2 = nonzeros(allIntensitiesM2);
noZeroIntensitiesM3 = nonzeros(allIntensitiesM3);
noZeroIntensitiesM4 = nonzeros(allIntensitiesM4);
noZeroIntensitiesM5 = nonzeros(allIntensitiesM5);
noZeroIntensitiesM6 = nonzeros(allIntensitiesM6);
noZeroIntensitiesM7 = nonzeros(allIntensitiesM7);


% Compute the mean pitch of each speaker over the entire video
meanIntensityH = mean(noZeroIntensitiesH);
meanIntensityC = mean(noZeroIntensitiesC);

meanIntensityF1 = mean(noZeroIntensitiesF1);
meanIntensityF2 = mean(noZeroIntensitiesF2);
meanIntensityF3 = mean(noZeroIntensitiesF3);
meanIntensityF4 = mean(noZeroIntensitiesF4);
meanIntensityF5 = mean(noZeroIntensitiesF5);
meanIntensityF6 = mean(noZeroIntensitiesF6);
meanIntensityF7 = mean(noZeroIntensitiesF7);
meanIntensityF8 = mean(noZeroIntensitiesF8);
meanIntensityF9 = mean(noZeroIntensitiesF9);

meanIntensityM1 = mean(noZeroIntensitiesM1);
meanIntensityM2 = mean(noZeroIntensitiesM2);
meanIntensityM3 = mean(noZeroIntensitiesM3);
meanIntensityM4 = mean(noZeroIntensitiesM4);
meanIntensityM5 = mean(noZeroIntensitiesM5);
meanIntensityM6 = mean(noZeroIntensitiesM6);
meanIntensityM7 = mean(noZeroIntensitiesM7);


% Do the same for the standard deviation.
stdIntensityH = std(noZeroIntensitiesH);
stdIntensityC = std(noZeroIntensitiesC);

stdIntensityF1 = std(noZeroIntensitiesF1);
stdIntensityF2 = std(noZeroIntensitiesF2);
stdIntensityF3 = std(noZeroIntensitiesF3);
stdIntensityF4 = std(noZeroIntensitiesF4);
stdIntensityF5 = std(noZeroIntensitiesF5);
stdIntensityF6 = std(noZeroIntensitiesF6);
stdIntensityF7 = std(noZeroIntensitiesF7);
stdIntensityF8 = std(noZeroIntensitiesF8);
stdIntensityF9 = std(noZeroIntensitiesF9);

stdIntensityM1 = std(noZeroIntensitiesM1);
stdIntensityM2 = std(noZeroIntensitiesM2);
stdIntensityM3 = std(noZeroIntensitiesM3);
stdIntensityM4 = std(noZeroIntensitiesM4);
stdIntensityM5 = std(noZeroIntensitiesM5);
stdIntensityM6 = std(noZeroIntensitiesM6);
stdIntensityM7 = std(noZeroIntensitiesM7);


%% Compute the pitch z-scores and add the normalized pitch data to the 
%  D struct.

numDiars = length(D);

for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(pitchTimes >= begTime & pitchTimes <= endTime );
    
    if whoNum == 1
        thisNormPitchList = (pitchVals(ff) - meanPitchH)/stdPitchH; 
        D(Dindx).normPitchList = thisNormPitchList;

    elseif whoNum == 2
        thisNormPitchList = (pitchVals(ff) - meanPitchC)/stdPitchC; 
        D(Dindx).normPitchList = thisNormPitchList;


    elseif whoNum == 3
        thisNormPitchList = (pitchVals(ff) - meanPitchF1)/stdPitchF1; 
        D(Dindx).normPitchList = thisNormPitchList;
            
    elseif whoNum == 4
        thisNormPitchList = (pitchVals(ff) - meanPitchF2)/stdPitchF2; 
        D(Dindx).normPitchList = thisNormPitchList;
    
    elseif whoNum == 5
        thisNormPitchList = (pitchVals(ff) - meanPitchF3)/stdPitchF3; 
        D(Dindx).normPitchList = thisNormPitchList;    
 
    elseif whoNum == 6
        thisNormPitchList = (pitchVals(ff) - meanPitchF4)/stdPitchF4; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 7
        thisNormPitchList = (pitchVals(ff) - meanPitchF5)/stdPitchF5; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 8
        thisNormPitchList = (pitchVals(ff) - meanPitchF6)/stdPitchF6; 
        D(Dindx).normPitchList = thisNormPitchList; 

    elseif whoNum == 9
        thisNormPitchList = (pitchVals(ff) - meanPitchF7)/stdPitchF7; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 10
        thisNormPitchList = (pitchVals(ff) - meanPitchF8)/stdPitchF8; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 11
        thisNormPitchList = (pitchVals(ff) - meanPitchF9)/stdPitchF9; 
        D(Dindx).normPitchList = thisNormPitchList;


    elseif whoNum == 12
        thisNormPitchList = (pitchVals(ff) - meanPitchM1)/stdPitchM1; 
        D(Dindx).normPitchList = thisNormPitchList;
            
    elseif whoNum == 13
        thisNormPitchList = (pitchVals(ff) - meanPitchM2)/stdPitchM2; 
        D(Dindx).normPitchList = thisNormPitchList;
    
    elseif whoNum == 14
        thisNormPitchList = (pitchVals(ff) - meanPitchM3)/stdPitchM3; 
        D(Dindx).normPitchList = thisNormPitchList;    
 
    elseif whoNum == 15
        thisNormPitchList = (pitchVals(ff) - meanPitchM4)/stdPitchM4; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 16
        thisNormPitchList = (pitchVals(ff) - meanPitchM5)/stdPitchM5; 
        D(Dindx).normPitchList = thisNormPitchList;    

    elseif whoNum == 17
        thisNormPitchList = (pitchVals(ff) - meanPitchM6)/stdPitchM6; 
        D(Dindx).normPitchList = thisNormPitchList; 

    elseif whoNum == 18
        thisNormPitchList = (pitchVals(ff) - meanPitchM7)/stdPitchM7; 
        D(Dindx).normPitchList = thisNormPitchList; 


    else 
        thisNormPitchList = zscore(pitchVals(ff));
        D(Dindx).normPitchList = thisNormPitchList;
    end
end 



%% Compute the intensity z-scores and add the normalized intensity data 
%  to the D struct.

numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(intensityTimes >= begTime & intensityTimes <= endTime );
    
    if whoNum == 1
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityH)/stdIntensityH; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 2
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityC)/stdIntensityC; 
        D(Dindx).normIntensityList = thisNormIntensityList;


    elseif whoNum == 3
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF1)/stdIntensityF1; 
        D(Dindx).normIntensityList = thisNormIntensityList;
            
    elseif whoNum == 4
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF2)/stdIntensityF2; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 5
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF3)/stdIntensityF3; 
        D(Dindx).normIntensityList = thisNormIntensityList;    
    
    elseif whoNum == 6
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF4)/stdIntensityF4; 
        D(Dindx).normIntensityList = thisNormIntensityList;
            
    elseif whoNum == 7
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF5)/stdIntensityF5; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 8
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF6)/stdIntensityF6; 
        D(Dindx).normIntensityList = thisNormIntensityList; 

    elseif whoNum == 9
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF7)/stdIntensityF7; 
        D(Dindx).normIntensityList = thisNormIntensityList;
            
    elseif whoNum == 10
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF8)/stdIntensityF8; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 11
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityF9)/stdIntensityF9; 
        D(Dindx).normIntensityList = thisNormIntensityList;


    elseif whoNum == 12
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM1)/stdIntensityM1; 
        D(Dindx).normIntensityList = thisNormIntensityList;
            
    elseif whoNum == 13
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM2)/stdIntensityM2; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 14
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM3)/stdIntensityM3; 
        D(Dindx).normIntensityList = thisNormIntensityList;    
    
    elseif whoNum == 15
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM4)/stdIntensityM4; 
        D(Dindx).normIntensityList = thisNormIntensityList;
            
    elseif whoNum == 16
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM5)/stdIntensityM5; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 17
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM6)/stdIntensityM6; 
        D(Dindx).normIntensityList = thisNormIntensityList;

    elseif whoNum == 18
        thisNormIntensityList = (cleanIntensities(ff) - meanIntensityM7)/stdIntensityM7; 
        D(Dindx).normIntensityList = thisNormIntensityList;


    else 
        thisNormIntensityList = zscore(intensityVals(ff));
        D(Dindx).normIntensityList = thisNormIntensityList;
    end
end 



%% Create vectors of the normalized pitch data for each speaker group.

% Create a vector of all the pitches corresponding to each speaker group.
allNormPitchesH = [];
for indx = 1:length(listH)
    newNormPitchH = D(listH(indx)).normPitchList; 
    allNormPitchesH = [allNormPitchesH; newNormPitchH];
end

allNormPitchesC = [];
for indx = 1:length(listC)
    newNormPitchC = D(listC(indx)).normPitchList;
    allNormPitchesC = [allNormPitchesC; newNormPitchC];
end


allNormPitchesF1 = [];
for indx = 1:length(listF1)
    newNormPitchF1 = D(listF1(indx)).normPitchList;
    allNormPitchesF1 = [allNormPitchesF1; newNormPitchF1];
end

allNormPitchesF2 = [];
for indx = 1:length(listF2)
    newNormPitchF2 = D(listF2(indx)).normPitchList;
    allNormPitchesF2 = [allNormPitchesF2; newNormPitchF2];
end

allNormPitchesF3 = [];
for indx = 1:length(listF3)
    newNormPitchF3 = D(listF3(indx)).normPitchList;
    allNormPitchesF3 = [allNormPitchesF3; newNormPitchF3];
end

allNormPitchesF4 = [];
for indx = 1:length(listF4)
    newNormPitchF4 = D(listF4(indx)).normPitchList;
    allNormPitchesF4 = [allNormPitchesF4; newNormPitchF4];
end

allNormPitchesF5 = [];
for indx = 1:length(listF5)
    newNormPitchF5 = D(listF5(indx)).normPitchList;
    allNormPitchesF5 = [allNormPitchesF5; newNormPitchF5];
end

allNormPitchesF6 = [];
for indx = 1:length(listF6)
    newNormPitchF6 = D(listF6(indx)).normPitchList;
    allNormPitchesF6 = [allNormPitchesF6; newNormPitchF6];
end

allNormPitchesF7 = [];
for indx = 1:length(listF7)
    newNormPitchF7 = D(listF7(indx)).normPitchList;
    allNormPitchesF7 = [allNormPitchesF7; newNormPitchF7];
end

allNormPitchesF8 = [];
for indx = 1:length(listF8)
    newNormPitchF8 = D(listF8(indx)).normPitchList;
    allNormPitchesF8 = [allNormPitchesF8; newNormPitchF8];
end

allNormPitchesF9 = [];
for indx = 1:length(listF9)
    newNormPitchF9 = D(listF9(indx)).normPitchList;
    allNormPitchesF9 = [allNormPitchesF9; newNormPitchF9];
end


allNormPitchesM1 = [];
for indx = 1:length(listM1)
    newNormPitchM1 = D(listM1(indx)).normPitchList;
    allNormPitchesM1 = [allNormPitchesM1; newNormPitchM1];
end

allNormPitchesM2 = [];
for indx = 1:length(listM2)
    newNormPitchM2 = D(listM2(indx)).normPitchList;
    allNormPitchesM2 = [allNormPitchesM2; newNormPitchM2];
end

allNormPitchesM3 = [];
for indx = 1:length(listM3)
    newNormPitchM3 = D(listM3(indx)).normPitchList;
    allNormPitchesM3 = [allNormPitchesM3; newNormPitchM3];
end

allNormPitchesM4 = [];
for indx = 1:length(listM4)
    newNormPitchM4 = D(listM4(indx)).normPitchList;
    allNormPitchesM4 = [allNormPitchesM4; newNormPitchM4];
end

allNormPitchesM5 = [];
for indx = 1:length(listM5)
    newNormPitchM5 = D(listM5(indx)).normPitchList;
    allNormPitchesM5 = [allNormPitchesM5; newNormPitchM5];
end

allNormPitchesM6 = [];
for indx = 1:length(listM6)
    newNormPitchM6 = D(listM6(indx)).normPitchList;
    allNormPitchesM6 = [allNormPitchesM6; newNormPitchM6];
end

allNormPitchesM7 = [];
for indx = 1:length(listM7)
    newNormPitchM7 = D(listM7(indx)).normPitchList;
    allNormPitchesM7 = [allNormPitchesM7; newNormPitchM7];
end



%% Create vectors of the normalized intensity data for each speaker group.

allNormIntensitiesH = [];
for indx = 1:length(listH)
    newNormIntensityH = D(listH(indx)).normIntensityList;
    allNormIntensitiesH = [allNormIntensitiesH; newNormIntensityH];
end

allNormIntensitiesC = [];
for indx = 1:length(listC)
    newNormIntensityC = D(listC(indx)).normIntensityList;
    allNormIntensitiesC = [allNormIntensitiesC; newNormIntensityC];
end


allNormIntensitiesF1 = [];
for indx = 1:length(listF1)
    newNormIntensityF1 = D(listF1(indx)).normIntensityList;
    allNormIntensitiesF1 = [allNormIntensitiesF1; newNormIntensityF1];
end

allNormIntensitiesF2 = [];
for indx = 1:length(listF2)
    newNormIntensityF2 = D(listF2(indx)).normIntensityList;
    allNormIntensitiesF2 = [allNormIntensitiesF2; newNormIntensityF2];
end

allNormIntensitiesF3 = [];
for indx = 1:length(listF3)
    newNormIntensityF3 = D(listF3(indx)).normIntensityList;
    allNormIntensitiesF3 = [allNormIntensitiesF3; newNormIntensityF3];
end

allNormIntensitiesF4 = [];
for indx = 1:length(listF4)
    newNormIntensityF4 = D(listF4(indx)).normIntensityList;
    allNormIntensitiesF4 = [allNormIntensitiesF4; newNormIntensityF4];
end

allNormIntensitiesF5 = [];
for indx = 1:length(listF5)
    newNormIntensityF5 = D(listF5(indx)).normIntensityList;
    allNormIntensitiesF5 = [allNormIntensitiesF5; newNormIntensityF5];
end

allNormIntensitiesF6 = [];
for indx = 1:length(listF6)
    newNormIntensityF6 = D(listF6(indx)).normIntensityList;
    allNormIntensitiesF6 = [allNormIntensitiesF6; newNormIntensityF6];
end

allNormIntensitiesF7 = [];
for indx = 1:length(listF7)
    newNormIntensityF7 = D(listF7(indx)).normIntensityList;
    allNormIntensitiesF7 = [allNormIntensitiesF7; newNormIntensityF7];
end

allNormIntensitiesF8 = [];
for indx = 1:length(listF8)
    newNormIntensityF8 = D(listF8(indx)).normIntensityList;
    allNormIntensitiesF8 = [allNormIntensitiesF8; newNormIntensityF8];
end

allNormIntensitiesF9 = [];
for indx = 1:length(listF9)
    newNormIntensityF9 = D(listF9(indx)).normIntensityList;
    allNormIntensitiesF9 = [allNormIntensitiesF9; newNormIntensityF9];
end


allNormIntensitiesM1 = [];
for indx = 1:length(listM1)
    newNormIntensityM1 = D(listM1(indx)).normIntensityList;
    allNormIntensitiesM1 = [allNormIntensitiesM1; newNormIntensityM1];
end

allNormIntensitiesM2 = [];
for indx = 1:length(listM2)
    newNormIntensityM2 = D(listM2(indx)).normIntensityList;
    allNormIntensitiesM2 = [allNormIntensitiesM2; newNormIntensityM2];
end

allNormIntensitiesM3 = [];
for indx = 1:length(listM3)
    newNormIntensityM3 = D(listM3(indx)).normIntensityList;
    allNormIntensitiesM3 = [allNormIntensitiesM3; newNormIntensityM3];
end

allNormIntensitiesM4 = [];
for indx = 1:length(listM4)
    newNormIntensityM4 = D(listM4(indx)).normIntensityList;
    allNormIntensitiesM4 = [allNormIntensitiesM4; newNormIntensityM4];
end

allNormIntensitiesM5 = [];
for indx = 1:length(listM5)
    newNormIntensityM5 = D(listM5(indx)).normIntensityList;
    allNormIntensitiesM5 = [allNormIntensitiesM5; newNormIntensityM5];
end

allNormIntensitiesM6 = [];
for indx = 1:length(listM6)
    newNormIntensityM6 = D(listM6(indx)).normIntensityList;
    allNormIntensitiesM6 = [allNormIntensitiesM6; newNormIntensityM6];
end

allNormIntensitiesM7 = [];
for indx = 1:length(listM7)
    newNormIntensityM7 = D(listM7(indx)).normIntensityList;
    allNormIntensitiesM7 = [allNormIntensitiesM7; newNormIntensityM7];
end



%% Give the histograms of the different pitch and intensity distributions
%  for the different speaker groups.


% Host.
%HPitchHistogram = histogram(allPitchesH);
%HIntensityHistogram = histogram(allIntensitiesH);

%HNormPitchHistogram = histogram(allNormPitchesH);
%HNormIntensityHistogram = histogram(allNormIntensitiesH);


% Female participants (1).
%F1PitchHistogram = histogram(allPitchesF1);
%F1IntensityHistogram = histogram(allIntensitiesF1);

%F1NormPitchHistogram = histogram(allNormPitchesF1);
%F1NormIntensityHistogram = histogram(allNormIntensitiesF1);

% Female participant 2.
%F2PitchHistogram = histogram(allPitchesF2);
%F2IntensityHistogram = histogram(allIntensitiesF2);

%F2NormPitchHistogram = histogram(allNormPitchesF2);
%F2NormIntensityHistogram = histogram(allNormIntensitiesF2);

% Female participant 3.
%F3PitchHistogram = histogram(allPitchesF3);
%F3IntensityHistogram = histogram(allIntensitiesF3);

%F3NormPitchHistogram = histogram(allNormPitchesF3);
%F3NormIntensityHistogram = histogram(allNormIntensitiesF3);

% Female participant 4.
%F4PitchHistogram = histogram(allPitchesF4);
%F4IntensityHistogram = histogram(allIntensitiesF4);

%F4NormPitchHistogram = histogram(allNormPitchesF4);
%F4NormIntensityHistogram = histogram(allNormIntensitiesF4);

% Female participant 5.
%F5PitchHistogram = histogram(allPitchesF5);
%F5IntensityHistogram = histogram(allIntensitiesF5);

%F5NormPitchHistogram = histogram(allNormPitchesF5);
%F5NormIntensityHistogram = histogram(allNormIntensitiesF5);

% Female participant 6.
%F6PitchHistogram = histogram(allPitchesF6);
%F6IntensityHistogram = histogram(allIntensitiesF6);

%F6NormPitchHistogram = histogram(allNormPitchesF6);
%F6NormIntensityHistogram = histogram(allNormIntensitiesF6);


% Male participants (1).
%M1PitchHistogram = histogram(allPitchesM1);
%M1IntensityHistogram = histogram(allIntensitiesM1);

%M1NormPitchHistogram = histogram(allNormPitchesM1);
%M1NormIntensityHistogram = histogram(allNormIntensitiesM1);

% Male participant 2.
%M2PitchHistogram = histogram(allPitchesM2);
%M2IntensityHistogram = histogram(allIntensitiesM2);

%M2NormPitchHistogram = histogram(allNormPitchesM2);
%M2NormIntensityHistogram = histogram(allNormIntensitiesM2);

% Male participant 3.
%M3PitchHistogram = histogram(allPitchesM3);
%M3IntensityHistogram = histogram(allIntensitiesM3);

%M3NormPitchHistogram = histogram(allNormPitchesM3);
%M3NormIntensityHistogram = histogram(allNormIntensitiesM3);

% Male participant 4.
%M4PitchHistogram = histogram(allPitchesM4);
%M4IntensityHistogram = histogram(allIntensitiesM4)

%M4NormPitchHistogram = histogram(allNormPitchesM4);
%M4NormIntensityHistogram = histogram(allNormIntensitiesM4);

% Male participant 5.
%M5PitchHistogram = histogram(allPitchesM5);
%M5IntensityHistogram = histogram(allIntensitiesM5)

%M5NormPitchHistogram = histogram(allNormPitchesM5);
%M5NormIntensityHistogram = histogram(allNormIntensitiesM5);

% Male participant 6.
%M6PitchHistogram = histogram(allPitchesM6);
%M6IntensityHistogram = histogram(allIntensitiesM6)

%M6NormPitchHistogram = histogram(allNormPitchesM6);
%M6NormIntensityHistogram = histogram(allNormIntensitiesM6);


% Control subject.
%CPitchHistogram = histogram(allPitchesC);
%CIntensityHistogram = histogram(allIntensitiesC)

%CNormPitchHistogram = histogram(allNormPitchesC);
%CNormIntensityHistogram = histogram(allNormIntensitiesC);
%pairMakerB.m
% Make struct Pr -- pairs of adjacent diar intervals.
% Some criteria applied to select "good" pairs.
% The purpose of the pairs is to investigate possible 
% correlation and pitch mimicry between the end of one
% diarization interval and the beginning of the next.
% Needs struct G, which has fields .longPitchVec, 
% longTimeVec, and whoNum.

% This B version does not interact, but just loops through
% ALL of struct G to create new struct Pr.

%% do the thing:
lenG = length(G); % G stands for Group of related pitchVecs
clear Pr %the Pair struct to build
Pindx = 0; %this will be the indx in Pf(Pindx).longPitchVec,
% etc.

for Gindx = 1:lenG-1

    % Indices for the turn pair. 
    thisG = G(Gindx);
    nextG = G(Gindx+1);


    % Give the numeric identity of the first person in the turn.
    thisWho = thisG.whoNum;
    if isempty(thisWho)
    msg = "missing whoNum"
    end
    % Skip if not young-female (1), old-female (2), old-male (3), or
    % control (4).
    if thisWho>18 
        continue
    end
    % Give the numeric identity of the second speaker in a turn.
    nextWho = nextG.whoNum;
    % Skip if not the right speaker group.
    if nextWho>18 
        continue
    end
   

    % Give the time vector and the pitch vector.  This will be used to set
    % up some rejection criteria.
    thisTimeVec = thisG.longTimeVec; 
    thisPitchVec = thisG.longPitchVec;
    thisNormPitchVec = thisG.normLongPitchVec;
    nextTimeVec = nextG.longTimeVec;
    nextPitchVec = nextG.longPitchVec;
    nextNormPitchVec = nextG.normLongPitchVec;
   

    Pindx = Pindx+1;

    % Give the identity of the first speaker in the turn.
    Pr(Pindx).who1 = thisWho;
    % Give the time data for the pitch times.
    Pr(Pindx).thisTimeVec = thisTimeVec; 
    % Add the first speaker's pitch features to the struct.
    Pr(Pindx).thisPitchVec = thisPitchVec;
    Pr(Pindx).thisPitchMean = mean(thisPitchVec);
    Pr(Pindx).thisPitchMax = max(thisPitchVec);
    Pr(Pindx).thisPitchMin = min(thisPitchVec);

    Pr(Pindx).thisNormPitchVec = thisNormPitchVec;
    Pr(Pindx).thisNormPitchMean = mean(thisNormPitchVec);
    Pr(Pindx).thisNormPitchMax = max(thisNormPitchVec);
    Pr(Pindx).thisNormPitchMin = min(thisNormPitchVec);
    

    % Now add the first speaker's intensity data.
    Pr(Pindx).thisIntensityVec = thisG.longIntensityVec;
    Pr(Pindx).thisIntensityMean = mean(thisG.longIntensityVec);
    Pr(Pindx).thisIntensityMax = max(thisG.longIntensityVec);
    Pr(Pindx).thisIntensityMin = min(thisG.longIntensityVec);

    % Now add the first speaker's normalized intensity data.
    Pr(Pindx).thisNormIntensityVec = thisG.normLongIntensityVec;
    Pr(Pindx).thisNormIntensityMean = mean(thisG.normLongIntensityVec);
    Pr(Pindx).thisNormIntensityMax = max(thisG.normLongIntensityVec);
    Pr(Pindx).thisNormIntensityMin = min(thisG.normLongIntensityVec);
  

    
    % Now do the same, but for the second speaker in the turn.
    
    % Give the identity of the second speaker in the turn.
    Pr(Pindx).who2 = nextWho;
    % Give the time data for when the speaker talks.
    Pr(Pindx).nextTimeVec = nextTimeVec;
    
    % Add the second speaker's pitch features to the struct.
    Pr(Pindx).nextPitchVec = nextPitchVec;
    Pr(Pindx).nextPitchMean = mean(nextPitchVec);
    Pr(Pindx).nextPitchMax = max(nextPitchVec);
    Pr(Pindx).nextPitchMin = min(nextPitchVec);

    Pr(Pindx).nextNormPitchVec = nextNormPitchVec;
    Pr(Pindx).nextNormPitchMean = mean(nextNormPitchVec);
    Pr(Pindx).nextNormPitchMax = max(nextNormPitchVec);
    Pr(Pindx).nextNormPitchMin = min(nextNormPitchVec);
 
    
    % Now add the second speaker's intensity data.
    Pr(Pindx).nextIntensityVec = nextG.longIntensityVec;
    Pr(Pindx).nextIntensityMean = mean(nextG.longIntensityVec);
    Pr(Pindx).nextIntensityMax = max(nextG.longIntensityVec);
    Pr(Pindx).nextIntensityMin = min(nextG.longIntensityVec);
    
    % Now add the second speaker's intensity data.
    Pr(Pindx).nextNormIntensityVec = nextG.normLongIntensityVec;
    Pr(Pindx).nextNormIntensityMean = mean(nextG.normLongIntensityVec);
    Pr(Pindx).nextNormIntensityMax = max(nextG.normLongIntensityVec);
    Pr(Pindx).nextNormIntensityMin = min(nextG.normLongIntensityVec);

    
end

msg = 'Finished making struct Pr.'
LengthPr = length(Pr)

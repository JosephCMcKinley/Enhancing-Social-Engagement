%readPraatIntensityTierOOB.m
% Read in a Praat  Intensity Tier
% Then put the times and pitches into a matrix and graph that.

% specify the file name.  This may be done Before this program.
%intensity_file = '8_11_21_Intensity_Tier'
%msg = strcat('The file: ',filename)
%intensityTierFile = '4_16_21_Intensity_Tier'

%% Read the exported Praat file into MATLAB:

textLines = readlines(intensityTierFile);
objectClass = textLines(2) %show what kind of tier this is
numberOfLines = length(textLines)

%% Get the number of points, etc:

stg = textLines(4);
startTime = numberize(stg);
stg = textLines(5); %should be xmax = 0,or similar
maxTime = numberize(stg) %my convenience function
stg = textLines(6); % like "points: size = 14311 "
x = split(stg,'='); x2 = x(2);
numPoints = str2num(x2);
intensityTimes = zeros(numPoints,1); %pre-allocate for speed
intensityVals = zeros(numPoints,1);

%% loop through all the points

startLine = 7;
offset = 5;
for pt = 1:numPoints
    stg1 = textLines(offset  + pt*3); %this is time as text
    numb = numberize(stg1);
    intensityTimes(pt)= numb;
    stg2 = textLines(offset+ 1 +pt*3); %value
    intensityVals(pt) = numberize(stg2); %this could be intens OR pitch
end

%% show the data:

if 0 %plotting turned off for now
%figure(11); clf
%plot(intensityTimes,intensityVals,'.-'); zoom xon; grid minor
%figure(12); clf
%plot(intensityTimes,intensityVals,'*'); zoom xon
%grid minor
%niceTitle = strrep(filename,'_',' '); %the "_" messes up title
%niceTitle = strcat("intensityVals for ",niceTitle);
%title(niceTitle)
end

%% get rid of numeric outlier points

if contains(objectClass,"Intensity")
    % It's SUPPOSED to be an Intensity file, not Pitch,
    % although thek file formats are similar.
    cleanIntensities = max(intensityVals,-10); %below this is essentially zero
    %figure(13); clf
    %plot(intensityTimes,cleanIntensities)
    %title('Intensity in dB, above noise floor')
    %zoom xon; grid minor
    %figure(14); clf
    linearIntensities = db2mag(cleanIntensities); %linear non-dB intensity values
    %plot(intensityTimes,linearIntensities)
    %title('Intensity only above noise floor, Linear scale')
    %zoom xon; grid minor
end

%% function to get number out of stgInp = numberValue

function numb = numberize(stgInp)
numb = extractAfter(stgInp,"=");
numb = double(numb);
end


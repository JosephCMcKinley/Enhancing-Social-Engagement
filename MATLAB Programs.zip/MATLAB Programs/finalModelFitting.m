%% Fit the linear regression model.


% Construct the design matrix using the Excel behavioral data.
designMatrix = [];

for s = 1:length(S)

    designMatrix = cat(1, designMatrix, S(s).Mtrx);

end



% Specify the predictor data and the response data.


% Behavioral Data.

% Social data.
socialData = designMatrix(:, 7);

% Humor data.
humorData = designMatrix(:, 8);

% Game question/answer data.
gameData = designMatrix(:, 9);

% Host cuing data.
cuingData = designMatrix(:, 10);

% Affirmation data.
affirmData = designMatrix(:, 11);

% Self-disclosure data.
selfdiscloseData = designMatrix(:, 12);

% Host correction data.
correctData = designMatrix(:, 13);

% Notable nonverbal reaction data.
nonverbalData = designMatrix(:, 14);

% Number engaged data.
numberData = designMatrix(:, 15);


% Combine all of the behavioral data into a single matrix.
behavioralData1 = cat(2, socialData, humorData);
behavioralData2 = cat(2, behavioralData1, gameData);
behavioralData3 = cat(2, behavioralData2, cuingData);
behavioralData4 = cat(2, behavioralData3, affirmData);
behavioralData5 = cat(2, behavioralData4, selfdiscloseData);
behavioralData6 = cat(2, behavioralData5, correctData);

finalBehavioralData = cat(2, behavioralData6, nonverbalData);


% Host ID data.

% Host 1.
host1Data = designMatrix(:, 16);

% Host 2.
host2Data = designMatrix(:, 17);

% Host 3.
host3Data = designMatrix(:, 18);

hostData1 = cat(2, host1Data, host2Data);
totalHostData = cat(2, hostData1, host3Data);



% Engagement score response.
engagementScores = designMatrix(:, 19);


engagementScores1 = [];
engagementScores1 = engagementScores;

engagementScores = 0.5*(engagementScores + engagementScores1);

%% Construct the time data matrix.  

% This consists of the total time spoken by host, participant, and control,
% the total speech time, the total silence time, speech ratio, silence
% ratio, and the percent time spoken by host, participant, and control 
% (so, 10 predictors in total).


% Obtain the total length of time for each event.
totalEventTime = designMatrix(:, 6) - designMatrix(:, 5);

% Calculate the total amount of silence time for each event.
silenceTime = totalEventTime - eventsTotalSpeechTimeData;

% Calculate the percentage of time per event that is speech.
totalSpeechRatio = eventsTotalSpeechTimeData./totalEventTime;

% Calculate the percentage of time per event that is silence.
totalSilenceRatio = silenceTime./totalEventTime;


% Calculate the percentage of time per event spoken by the host.
hostSpeechRatio = eventsHostSpeechTimeData./totalEventTime;

% Calculate the percentage of time per event spoken by the participants.
participantSpeechRatio = eventsParticipantSpeechTimeData./totalEventTime;

% Calculate the percentage of time per event spoken by the control.
controlSpeechRatio = eventsControlSpeechTimeData./totalEventTime;


% Put all the time data together into one matrix.
timeDataMatrix1 = cat(2, eventsHostSpeechTimeData, eventsParticipantSpeechTimeData);
timeDataMatrix2 = cat(2, timeDataMatrix1, eventsControlSpeechTimeData);
timeDataMatrix3 = cat(2, timeDataMatrix2, eventsTotalSpeechTimeData);
timeDataMatrix3 = cat(2, timeDataMatrix2, silenceTime);

timeDataMatrix4 = cat(2, timeDataMatrix3, hostSpeechRatio);
timeDataMatrix5 = cat(2, timeDataMatrix4, participantSpeechRatio);
timeDataMatrix6 = cat(2, timeDataMatrix5, controlSpeechRatio);
timeDataMatrix7 = cat(2, timeDataMatrix6, totalSpeechRatio);

finalTimeDataMatrix = cat(2, timeDataMatrix7, totalSilenceRatio);


%% Consider the behavioral data.  Fit it to the engagement data in a 
%  linear regression model.


% Social model.
socialModel = fitlm(socialData, engagementScores)

% Humor model.
humorModel = fitlm(humorData, engagementScores)

% Game question/answer model.
gameModel = fitlm(gameData, engagementScores)

% Host cuing model.
cuingModel = fitlm(cuingData, engagementScores)

% Affirmation model.
affirmModel = fitlm(affirmData, engagementScores)

% Self-disclosure model.
selfdiscloseModel = fitlm(selfdiscloseData, engagementScores)

% Host correction model.
correctModel = fitlm(correctData, engagementScores)

% Notable nonverbal reaction data.
nonverbalModel = fitlm(nonverbalData, engagementScores)



% Include all the behavioral variables in a single model.
behavioralModel = fitlm(finalBehavioralData, engagementScores)



%% Fit a linear regression model to the time data.

% Amount of time host speaks.
hostTimeModel = fitlm(eventsHostSpeechTimeData, engagementScores)

% Amount of time participants speak.
participantTimeModel = fitlm(eventsParticipantSpeechTimeData, engagementScores)

% Amount of time control speaks.
controlTimeModel = fitlm(eventsControlSpeechTimeData, engagementScores)


% Amount of speech time.
totalSpeechTimeModel = fitlm(eventsTotalSpeechTimeData, engagementScores)

% Amount of silence time.
totalSilenceTimeModel = fitlm(silenceTime, engagementScores)



% Ratio of time host speaks.
hostRatioModel = fitlm(hostSpeechRatio, engagementScores)

% Ratio of time participants speak.
participantRatioModel = fitlm(participantSpeechRatio, engagementScores)

% Ratio of time control speaks.
controlRatioModel = fitlm(controlSpeechRatio, engagementScores)


% Ratio of speech time.
totalSpeechRatioModel = fitlm(totalSpeechRatio, engagementScores)

% Ratio of silence time.
totalSilenceRatioModel = fitlm(totalSilenceRatio, engagementScores)


% Include all of the time data in a model.
totalTimeModel = fitlm(finalTimeDataMatrix, engagementScores)



% Try a model with just the most significant time predictors.
importantTimeDataMatrix1 = cat(2, eventsParticipantSpeechTimeData, participantSpeechRatio);
importantTimeDataMatrix2 = cat(2, importantTimeDataMatrix1, eventsHostSpeechTimeData);
importantTimeDataMatrix3 = cat(2, importantTimeDataMatrix2, eventsControlSpeechTimeData);
importantTimeDataMatrix4 = cat(2, importantTimeDataMatrix3, totalSilenceRatio);


importantTimeModel = fitlm(importantTimeDataMatrix4, engagementScores)


timeAndBehaviorData = cat(2, finalTimeDataMatrix, finalBehavioralData);
%% Fit a linear regression model to the other predictor variables.


% Host ID.
host1Model = fitlm(host1Data, engagementScores)

host2Model = fitlm(host2Data, engagementScores)

host3Model = fitlm(host3Data, engagementScores)

totalHostModel = fitlm(totalHostData, engagementScores)


% Number of people engaged.
numberModel = fitlm(numberData, engagementScores)


dataA = cat(2, totalHostData, numberData);

dataB = cat(2, dataA, timeAndBehaviorData);


totalModelA = fitlm(dataB, engagementScores)




%% Fit a linear regression model to the acoustic data.

meanPitchModel = fitlm(abs(meanPitchScores), engagementScores)
maxPitchModel = fitlm(abs(maxPitchScores), engagementScores)
minPitchModel = fitlm(abs(minPitchScores), engagementScores)


meanIntensityModel = fitlm(abs(meanIntensityScores), engagementScores)
maxIntensityModel = fitlm(abs(maxIntensityScores), engagementScores)
minIntensityModel = fitlm(abs(minIntensityScores), engagementScores)


pitchData1 = cat(2, abs(meanPitchScores), abs(maxPitchScores));
pitchData2 = cat(2, pitchData1, abs(minPitchScores));

intensityData1 = cat(2, abs(meanIntensityScores), abs(maxIntensityScores));
intensityData2 = cat(2, intensityData1, abs(minIntensityScores));


totalPitchModel = fitlm(pitchData2, engagementScores)

totalIntensityModel = fitlm(intensityData2, engagementScores)


totalAcousticData = cat(2, pitchData2, intensityData2);


totalAcousticModel = fitlm(totalAcousticData, engagementScores)



%% Put all of the predictors together into a general model.

totalData1 = cat(2, finalBehavioralData, totalHostData);
totalData2 = cat(2, totalData1, numberData);
totalData3 = cat(2, totalData2, importantTimeDataMatrix4);
totalData4 = cat(2, totalData3, totalAcousticData);

finalModel = fitlm(totalData4, engagementScores)


finalModelB = fitlm(totalData3, engagementScores)
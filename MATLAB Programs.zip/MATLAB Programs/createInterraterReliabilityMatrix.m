% Read in the first set of engagement scores, and then read in the second.

confusionchart(engagementScores, engagementScores1, "Normalization","total-normalized")
%% Initialize the statistics vectors for the Levitan analysis.
%  These are the final results of the many statistical tests that Levitan
%  uses in her "Measuring Acoustic-Prosodic Entrainment" paper.

% Turn-level proximity test.  
% 
% This is a paired t-test.  We want the p-values, the t-statistic, and the 
% degrees of freedom.  
% 
% Do this for mean, max, and min pitch (1,2,3) and intensity (4,5,6).

P11 = [];
T11 = [];
DF11 = [];
P12 = [];
T12 = [];
DF12 = [];
P13 = [];
T13 = [];
DF13 = [];
P14 = [];
T14 = [];
DF14 = [];
P15 = [];
T15 = [];
DF15 = [];
P16 = [];
T16 = [];
DF16 = [];



%% Turn-level synchrony test.

% This measures the Pearson correlation of two speaker's features in a turn.
% We want the p-values and the r-values for each feature.
P21 = [];
R21 = [];
P22 = [];
R22 = [];
P23 = [];
R23 = [];
P24 = [];
R24 = [];
P25 = [];
R25 = [];
P26 = [];
R26 = [];


%% Initialize the global data.

%  This includes a vector containing the lengths of all turns for the 
%  host, participants, and control, as well as the percent time spoken
%  by the various speaker groups.

allTimeLengthVec = [];

allParticipantPercentTimeSpokenVec = [];

allHostPercentTimeSpokenVec = [];

allControlPercentTimeSpokenVec = [];

%% Initialize the time data.

finalTimeDataMatrix = [];

videoPairNumberVec = [];
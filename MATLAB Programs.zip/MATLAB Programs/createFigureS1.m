figure;
subplot(1,2,1);
h = histfit(allPitchesH);
title('Host 1 Pitches');
xlabel('Pitch (Hz)');
ylabel('Number of Observations');

subplot(1,2,2);
h = histfit(allIntensitiesH);
title('Host 1 Intensities');
xlabel('Intensity (dB)');
ylabel('Number of Observations');
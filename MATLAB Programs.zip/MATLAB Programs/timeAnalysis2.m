clear C


eventsHostSpeechTimeData = [];
eventsParticipantSpeechTimeData = [];
eventsControlSpeechTimeData = [];
eventsTotalSpeechTimeData = [];

for s = 1:length(S)

    behavioralDataMatrix = S(s).Mtrx;
    timeDataMatrix = finalTimeDataMatrix((find(finalTimeDataMatrix(:, 1) == s)), :);

    for e = 1:size(behavioralDataMatrix, 1)
    
        hostSpeechTime = [];
        hostSpeechTimeStart = [];
        hostSpeechTimeEnd = [];
        participantSpeechTime = [];
        participantSpeechTimeStart = [];
        participantSpeechTimeEnd = [];
        controlSpeechTime = [];
        controlSpeechTimeStart = [];
        controlSpeechTimeEnd = [];

        for g = 1:length(timeDataMatrix)

            if timeDataMatrix(g, 4) == 1 

                if ((behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(behavioralDataMatrix(e, 6) >= timeDataMatrix(g, 3)))
                
                    hostSpeechTimeStart = [hostSpeechTimeStart; timeDataMatrix(g, 2)];
                    hostSpeechTimeEnd = [hostSpeechTimeEnd; timeDataMatrix(g, 3)];

                    hostSpeechTime = [hostSpeechTime; timeDataMatrix(g, 3) - timeDataMatrix(g, 2)];

                elseif ((timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 5))&(behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 3))&(timeDataMatrix(g, 3)) <= behavioralDataMatrix(e, 6))
            
                    hostSpeechTimeStart = [hostSpeechTimeStart; behavioralDataMatrix(e, 5)];
                    hostSpeechTimeEnd = [hostSpeechTimeEnd; timeDataMatrix(g, 3)];

                    hostSpeechTime = [hostSpeechTime; timeDataMatrix(g, 3) - behavioralDataMatrix(e, 5)];

                elseif (behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 6))&(behavioralDataMatrix(e, 6) <= timeDataMatrix(g, 3))

                    hostSpeechTimeStart = [hostSpeechTimeStart; timeDataMatrix(g, 2)];
                    hostSpeechTimeEnd = [hostSpeechTimeEnd; behavioralDataMatrix(e, 6)];

                    hostSpeechTime = [hostSpeechTime; behavioralDataMatrix(e, 6) - timeDataMatrix(g, 2)];

                end    

            elseif (timeDataMatrix(g, 4)==3)||(timeDataMatrix(g, 4)==4)||(timeDataMatrix(g, 4)==5)||(timeDataMatrix(g, 4)==6)||...
                    (timeDataMatrix(g, 4)==7)||(timeDataMatrix(g, 4)==8)||(timeDataMatrix(g, 4)==9)||(timeDataMatrix(g, 4)==10)||...
                    (timeDataMatrix(g, 4)==11)||(timeDataMatrix(g, 4)==12)||(timeDataMatrix(g, 4)==13)||(timeDataMatrix(g, 4)==14)||...
                    (timeDataMatrix(g, 4)==15)||(timeDataMatrix(g, 4)==16)||(timeDataMatrix(g, 4)==17)||(timeDataMatrix(g, 4)==18)
                    

                if ((behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(behavioralDataMatrix(e, 6) >= timeDataMatrix(g, 3)))
                
                    participantSpeechTimeStart = [participantSpeechTimeStart; timeDataMatrix(g, 2)];
                    participantSpeechTimeEnd = [participantSpeechTimeEnd; timeDataMatrix(g, 3)];

                    participantSpeechTime = [participantSpeechTime; timeDataMatrix(g, 3) - timeDataMatrix(g, 2)];

                elseif ((timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 5))&(behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 3))&(timeDataMatrix(g, 3)) <= behavioralDataMatrix(e, 6))
            
                    participantSpeechTimeStart = [participantSpeechTimeStart; behavioralDataMatrix(e, 5)];
                    participantSpeechTimeEnd = [participantSpeechTimeEnd; timeDataMatrix(g, 3)];

                    participantSpeechTime = [participantSpeechTime; timeDataMatrix(g, 3) - behavioralDataMatrix(e, 5)];

                elseif (behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 6))&(behavioralDataMatrix(e, 6) <= timeDataMatrix(g, 3))

                    participantSpeechTimeStart = [participantSpeechTimeStart; timeDataMatrix(g, 2)];
                    participantSpeechTimeEnd = [participantSpeechTimeEnd; behavioralDataMatrix(e, 6)];

                    participantSpeechTime = [participantSpeechTime; behavioralDataMatrix(e, 6) - timeDataMatrix(g, 2)];

                end   


            elseif timeDataMatrix(g, 4) == 2
                    

                if ((behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(behavioralDataMatrix(e, 6) >= timeDataMatrix(g, 3)))
                
                    controlSpeechTimeStart = [controlSpeechTimeStart; timeDataMatrix(g, 2)];
                    controlSpeechTimeEnd = [controlSpeechTimeEnd; timeDataMatrix(g, 3)];

                    controlSpeechTime = [controlSpeechTime; timeDataMatrix(g, 3) - timeDataMatrix(g, 2)];

                elseif ((timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 5))&(behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 3))&(timeDataMatrix(g, 3)) <= behavioralDataMatrix(e, 6))
            
                    controlSpeechTimeStart = [controlSpeechTimeStart; behavioralDataMatrix(e, 5)];
                    controlSpeechTimeEnd = [controlSpeechTimeEnd; timeDataMatrix(g, 3)];

                    controlSpeechTime = [controlSpeechTime; timeDataMatrix(g, 3) - behavioralDataMatrix(e, 5)];

                elseif (behavioralDataMatrix(e, 5) <= timeDataMatrix(g, 2))&(timeDataMatrix(g, 2) <= behavioralDataMatrix(e, 6))&(behavioralDataMatrix(e, 6) <= timeDataMatrix(g, 3))

                    controlSpeechTimeStart = [controlSpeechTimeStart; timeDataMatrix(g, 2)];
                    controlSpeechTimeEnd = [controlSpeechTimeEnd; behavioralDataMatrix(e, 6)];

                    controlSpeechTime = [controlSpeechTime; behavioralDataMatrix(e, 6) - timeDataMatrix(g, 2)];

                end   
           end
        
        end


        totalHostSpeechTime = sum(hostSpeechTime);
        totalParticipantSpeechTime = sum(participantSpeechTime);
        totalControlSpeechTime = sum(controlSpeechTime);

        totalSpeechTime = totalHostSpeechTime + totalParticipantSpeechTime + totalControlSpeechTime;

        C(e).hostStartTime = hostSpeechTimeStart;
        C(e).hostEndTime = hostSpeechTimeEnd;
        C(e).hostTime = hostSpeechTime;
        C(e).totalHostTime = sum(hostSpeechTime);
        C(e).participantStartTime = participantSpeechTimeStart;
        C(e).participantEndTime = participantSpeechTimeEnd;
        C(e).participantTime = participantSpeechTime;
        C(e).totalParticipantTime = sum(participantSpeechTime);
        C(e).controlStartTime = controlSpeechTimeStart;
        C(e).controlEndTime = controlSpeechTimeEnd;
        C(e).controlTime = controlSpeechTime;
        C(e).totalControlTime = sum(controlSpeechTime);

        

        eventsHostSpeechTimeData = [eventsHostSpeechTimeData; totalHostSpeechTime];
        eventsParticipantSpeechTimeData = [eventsParticipantSpeechTimeData; totalParticipantSpeechTime];
        eventsControlSpeechTimeData = [eventsControlSpeechTimeData; totalControlSpeechTime];
        eventsTotalSpeechTimeData = [eventsTotalSpeechTimeData; totalSpeechTime];

    end
    
end

%stest = S(1).Mtrx


%test = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 1)), :)

%test2 = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 2)), :)

%test4 = finalAcousticDataMatrix((find(finalAcousticDataMatrix(:, 1) == 4)), :)


%% Initialize the acoustic data vectors.

individualsList = [];

timeBoundsStartList = [];
timeBoundsEndList = [];

meanPitchList = [];
maxPitchList = [];
minPitchList = [];

meanIntensityList = [];
maxIntensityList = [];
minIntensityList = [];

%% Run a loop over all pairs to construct the acoustic data table for
%  a given video.

for g = 1:length(G)

    % Obtain the relevant data from the Pr struct.
    
    thisIndividual = G(g).whoNum;
    
    thisTimeVec = G(g).longTimeVec;
    timeBoundStart = thisTimeVec(1);
    timeBoundEnd = thisTimeVec(end);

    thisPitchVec = G(g).normLongPitchVec;
    thisMeanPitch = mean(thisPitchVec);
    thisMaxPitch = max(thisPitchVec);
    thisMinPitch = min(thisPitchVec);

    thisIntensityVec = G(g).normLongIntensityVec;
    thisMeanIntensity = mean(thisIntensityVec);
    thisMaxIntensity = max(thisIntensityVec);
    thisMinIntensity = min(thisIntensityVec);
  
    % Add the relevant data to the vectors we initialized.
    
    timeBoundsStartList = [timeBoundsStartList; timeBoundStart];
    timeBoundsEndList = [timeBoundsEndList; timeBoundEnd];

    individualsList = [individualsList; thisIndividual];

    meanPitchList = [meanPitchList; thisMeanPitch];
    maxPitchList = [maxPitchList; thisMaxPitch];
    minPitchList = [minPitchList; thisMinPitch];

    meanIntensityList = [meanIntensityList; thisMeanIntensity];
    maxIntensityList = [maxIntensityList; thisMaxIntensity];
    minIntensityList = [minIntensityList; thisMinIntensity];

end

%% Compute the acoustic statistics (feature differences, time data,  
%  video ID, and individual ID for the given video.


% This gives us the video number (in chronological order).
numberSpeechBlurbsVec = ones(length(G), 1)*idx;

% Construct the acoustic data matrix by iteratively concatenating.
timeDataMatrix1 = cat(2, numberSpeechBlurbsVec, timeBoundsStartList);
timeDataMatrix2 = cat(2, timeDataMatrix1, timeBoundsEndList);

timeDataMatrix3 = cat(2, timeDataMatrix2, individualsList);

timeDataMatrix4 = cat(2, timeDataMatrix3, meanPitchList);
timeDataMatrix5 = cat(2, timeDataMatrix4, maxPitchList);
timeDataMatrix6 = cat(2, timeDataMatrix5, minPitchList);

timeDataMatrix7 = cat(2, timeDataMatrix6, meanIntensityList);
timeDataMatrix8 = cat(2, timeDataMatrix7, maxIntensityList);
timeDataMatrix9 = cat(2, timeDataMatrix8, minIntensityList);

% Iteratively concatenate the new acoustic data matrix to the matrices for previous 
% videos.  This gives us one giant acoustic data matrix for all the 
% videos.
finalTimeDataMatrix = cat(1, finalTimeDataMatrix, timeDataMatrix9);



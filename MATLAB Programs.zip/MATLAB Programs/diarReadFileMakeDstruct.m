%diarReadFileMakeDstruct.m
%Just reads in a diarization file containing text-grid times
%  and the "Who" person category like "YF" or "OM"
% Puts the data into a D struct
% does NOT mess with pitch!

%% set up file names:
%diarFile = "8_11_21_Full_Diarization";
% pitch and intensity files are not read in here.

%diarizationFile = "4_16_21_Full_Diarization";

%% read in the diarization file and show example lines here:
DL = readlines(diarizationFile); %this is diarLines, short name
%     "File type = "ooTextFile""
%     "Object class = "TextGrid""
%     ""
%     "xmin = 0 "
%     "xmax = 1916.064 "
%     "tiers? <exists> "
%     "size = 3 "  real data items for each item -- a triplet
%      xmin and xmax are TIMES (of the text tier entries)
%      The other item is 'text"  which is "YF" or "OF" , etc.
%       NOTE: There are FOUR related lines for each thinger in the file,
%        so I call these groups "quadlets"
%     "item []: "   %this is line 8?
%     "    item [1]:"  Made item [2], etc., go away?
%     "        class = "IntervalTier" "
%     "        name = "union" "
%     "        xmin = 0 "  %line 12
%     "        xmax = 1916.064 "  %line 13
%     "        intervals: size = 2424 "  %line 14
%     "        intervals [1]:"  %line 15  %will be the startLine
%     "            xmin = 0 "  %line 16
%     "            xmax = 1.0519999999999414 "
%     "            text = "silent" "
%     "        intervals [2]:"
%     "            xmin = 1.0519999999999414 "
%     "            xmax = 2.2319999999999416 "
%     "            text = "YF" "
%     "        intervals [3]:"
%     "            xmin = 2.2319999999999416 "
%     "            xmax = 3.2219999999999414 "
%     "            text = "silent" "
%     "        intervals [4]:"
%     "            xmin = 3.2219999999999414 "
%     "            xmax = 3.5519999999999414 "
%     "            text = "YF" "
% 

%% find how much data:
numTextLines= length(DL); %but there are prolog lines
DLnumQuadletsStg = DL(14); %like    intervals: size = 2424 "  %line 14
numQuadlets = numberize(DLnumQuadletsStg); %xmin, xmax,text
DLxminStg = DL(12); % like   xmin = 0 "  %line 12  start time of whole tier
DLxmaxStg = DL(13); % like   xmax = 1916.064 "  %line 13 max time in whole tier

startLine = 15;
overallxmin = DL(12); overallxminTime = numberize(overallxmin);
%  above is starting time of whole tier, usually zero seconds
overallxmax = DL(13); overallxmaxTime = numberize(overallxmax);
%  above is ending time for the whole shebang (tier)

%% make whoDict if it's not already present:
if ~exist("WhoDict")
    makeWhoDictionary
end

%% loop thru the data:
clear D % D struct for Diarization
%numQuadlets = 1; %testing
for iQuad = 1:numQuadlets
    thisLine = startLine-4 +  4 * iQuad; %like  intervals [1]:"   
    xmin = DL(thisLine+1); xmin = numberize(xmin); %first time in Interval
    xmax = DL(thisLine+2); xmax = numberize(xmax); %last time in this int
    txtWho = DL(thisLine+3);
    txtWho = fixTxt(txtWho); %get rid of spaces and = sign
    if txtWho == ""
        txtWho = "badWho"; 
    end
    if ~isKey(WhoDict,txtWho)
        txtWho = "badWho";
    end
    D(iQuad).xmin = xmin;
    D(iQuad).xmax = xmax;
    D(iQuad).txtWho = txtWho;
    D(iQuad).whoNum = WhoDict(txtWho); %for convenience later in analysis
  
end

%% Get the pitch values within each diary entry in D:
%clear or intialize something
numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(pitchTimes >= begTime & pitchTimes <= endTime );
    thisPitchList = pitchVals(ff); %this ignores gaps in
    D(Dindx).pitchList = thisPitchList;
end

%% Get the pitch times within each diary entry in D:
%clear or intialize something
numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(pitchTimes >= begTime & pitchTimes <= endTime );
    thisPitchTimeList = pitchTimes(ff); %this ignores gaps in
    D(Dindx).pitchTimeList = thisPitchTimeList;
end

%% Get the intensity values within each diary entry in D:
%clear or intialize something
numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(intensityTimes >= begTime & intensityTimes <= endTime );
    thisIntensityList = cleanIntensities(ff); %this ignores gaps in
    D(Dindx).intensityList = thisIntensityList;
end

%% Get the intensity times within each diary entry in D:
%clear or intialize something
numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(intensityTimes >= begTime & intensityTimes <= endTime );
    thisIntensityTimeList = intensityTimes(ff); %this ignores gaps in
    D(Dindx).intensityTimeList = thisIntensityTimeList;
end

%% Get the linearized intensity values within each diary entry in D:
%clear or intialize something
numDiars = length(D);
for Dindx = 1:numDiars
    Dx = D(Dindx);
    begTime = Dx.xmin; endTime= Dx.xmax;
    whoNum = Dx.whoNum;
    ff = find(intensityTimes >= begTime & intensityTimes <= endTime );
    thisLinearIntensityList = linearIntensities(ff); %this ignores gaps in
    D(Dindx).linearIntensityList = thisLinearIntensityList;
end

%% function to get number out of stgInp = numberValue
function numb = numberize(stgInp)
numb = extractAfter(stgInp,"=");
numb = double(numb);
end

function cleanTxt = fixTxt(stgInp);
cleanTxt = extractAfter(stgInp,"=");
cleanTxt = erasePunctuation(cleanTxt); %remove quotation marks,etc.
cleanTxt = strrep(cleanTxt," ",""); %clunky matlab
end

